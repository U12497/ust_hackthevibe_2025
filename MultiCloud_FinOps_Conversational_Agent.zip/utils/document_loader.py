import os
import glob
from typing import List, Dict, Any
import PyPDF2
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.docstore.document import Document
import streamlit as st

class DocumentLoader:
    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
        )
        
        project = os.getenv("GOOGLE_CLOUD_PROJECT")
        region = os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
        
        # Try different embedding models based on availability
        try:
            self.embeddings = VertexAIEmbeddings(
                model_name="text-embedding-004",
                project=project,
                location=region
            )
        except Exception:
            try:
                # Fallback to a more widely available model
                self.embeddings = VertexAIEmbeddings(
                    model_name="textembedding-gecko@001",
                    project=project,
                    location=region
                )
            except Exception:
                # Final fallback - use sentence transformers for local embeddings
                st.warning("⚠️ Vertex AI embeddings not available, using local embeddings")
                from langchain.embeddings import HuggingFaceEmbeddings
                self.embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        self.vectorstore = None
    
    def load_pdfs_from_directory(self, pdf_directory: str) -> List[Document]:
        """Load all PDF files from a directory"""
        documents = []
        pdf_files = glob.glob(os.path.join(pdf_directory, "*.pdf"))
        
        if not pdf_files:
            st.warning(f"No PDF files found in {pdf_directory}")
            return documents
        
        for pdf_file in pdf_files:
            try:
                with open(pdf_file, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    text = ""
                    for page in pdf_reader.pages:
                        text += page.extract_text()
                    
                    # Create document with metadata
                    doc = Document(
                        page_content=text,
                        metadata={"source": os.path.basename(pdf_file)}
                    )
                    documents.append(doc)
            except Exception as e:
                st.error(f"Error loading {pdf_file}: {str(e)}")
        
        return documents
    
    def create_vectorstore(self, documents: List[Document]) -> FAISS:
        """Create FAISS vectorstore from documents"""
        if not documents:
            # Create empty vectorstore with sample document
            sample_doc = Document(
                page_content="FinOps is a discipline that combines financial accountability with cloud operations.",
                metadata={"source": "default"}
            )
            documents = [sample_doc]
        
        # Split documents into chunks
        texts = self.text_splitter.split_documents(documents)
        
        # Create vectorstore
        vectorstore = FAISS.from_documents(texts, self.embeddings)
        return vectorstore
    
    def load_and_index_documents(self, pdf_directory: str) -> FAISS:
        """Main method to load PDFs and create vectorstore"""
        documents = self.load_pdfs_from_directory(pdf_directory)
        vectorstore = self.create_vectorstore(documents)
        self.vectorstore = vectorstore
        return vectorstore
    
    def search_documents(self, query: str, k: int = 5) -> List[Document]:
        """Search for relevant documents"""
        if self.vectorstore is None:
            return []
        return self.vectorstore.similarity_search(query, k=k)