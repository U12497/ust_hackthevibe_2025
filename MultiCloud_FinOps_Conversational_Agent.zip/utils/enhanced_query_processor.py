"""
Enhanced Multi-Cloud Query Processor for FinOps Chatbot
Provides generic multi-cloud answers by default with focused, specific responses
"""

import re
from typing import Dict, Any, List, Tuple

class EnhancedQueryProcessor:
    """Enhanced query processor that provides multi-cloud responses by default"""
    
    def __init__(self):
        # Cloud-specific keywords for explicit targeting
        self.cloud_keywords = {
            'gcp': ['gcp', 'google cloud', 'compute engine', 'cloud storage', 'bigquery', 'cloud run', 'gke'],
            'aws': ['aws', 'amazon web services', 'ec2', 's3', 'lambda', 'rds', 'cloudfront', 'route53'],
            'azure': ['azure', 'microsoft azure', 'virtual machines', 'blob storage', 'azure functions', 'cosmos db']
        }
        
        # FinOps topic categories for focused responses
        self.finops_topics = {
            'cost_optimization': ['cost optimization', 'reduce costs', 'save money', 'lower bills', 'cost reduction'],
            'billing_analysis': ['billing', 'costs', 'spending', 'expenses', 'charges', 'usage analysis'],
            'resource_management': ['resources', 'instances', 'scaling', 'rightsizing', 'utilization'],
            'governance': ['governance', 'policies', 'compliance', 'controls', 'best practices'],
            'monitoring': ['monitoring', 'alerts', 'dashboards', 'reporting', 'visibility'],
            'forecasting': ['forecast', 'prediction', 'budget', 'planning', 'trends']
        }
    
    def analyze_query(self, query: str) -> Dict[str, Any]:
        """Analyze query to determine intent and scope"""
        query_lower = query.lower()
        
        # 1. Check for explicit cloud targeting
        target_clouds = self._detect_target_clouds(query_lower)
        
        # 2. Identify FinOps topic focus
        primary_topic = self._identify_primary_topic(query_lower)
        
        # 3. Determine response scope
        response_scope = self._determine_response_scope(query_lower, target_clouds)
        
        # 4. Extract specific question focus
        question_focus = self._extract_question_focus(query)
        
        return {
            'target_clouds': target_clouds,
            'primary_topic': primary_topic,
            'response_scope': response_scope,
            'question_focus': question_focus,
            'is_multi_cloud': len(target_clouds) == 0 or len(target_clouds) > 1,
            'requires_data_analysis': self._needs_data_analysis(query_lower)
        }
    
    def _detect_target_clouds(self, query: str) -> List[str]:
        """Detect which clouds are explicitly mentioned"""
        mentioned_clouds = []
        
        for cloud, keywords in self.cloud_keywords.items():
            if any(keyword in query for keyword in keywords):
                mentioned_clouds.append(cloud)
        
        return mentioned_clouds
    
    def _identify_primary_topic(self, query: str) -> str:
        """Identify the main FinOps topic being asked about"""
        topic_scores = {}
        
        for topic, keywords in self.finops_topics.items():
            score = sum(1 for keyword in keywords if keyword in query)
            if score > 0:
                topic_scores[topic] = score
        
        if topic_scores:
            return max(topic_scores, key=topic_scores.get)
        
        return 'general_finops'
    
    def _determine_response_scope(self, query: str, target_clouds: List[str]) -> str:
        """Determine if response should be multi-cloud or cloud-specific"""
        # Explicit multi-cloud indicators
        multi_cloud_indicators = [
            'all clouds', 'multi cloud', 'cross cloud', 'compare', 
            'across providers', 'different clouds', 'various clouds'
        ]
        
        if any(indicator in query for indicator in multi_cloud_indicators):
            return 'multi_cloud_explicit'
        elif len(target_clouds) == 1:
            return f'single_cloud_{target_clouds[0]}'
        elif len(target_clouds) > 1:
            return 'multi_cloud_comparative'
        else:
            return 'multi_cloud_default'  # Default to multi-cloud
    
    def _extract_question_focus(self, query: str) -> Dict[str, Any]:
        """Extract what specifically is being asked"""
        focus = {
            'question_type': 'general',
            'specific_aspects': [],
            'is_how_to': False,
            'is_what_is': False,
            'is_comparison': False,
            'is_recommendation': False
        }
        
        query_lower = query.lower()
        
        # Question type detection
        if query_lower.startswith(('how to', 'how can', 'how do')):
            focus['question_type'] = 'how_to'
            focus['is_how_to'] = True
        elif query_lower.startswith(('what is', 'what are', 'define')):
            focus['question_type'] = 'definition'
            focus['is_what_is'] = True
        elif any(word in query_lower for word in ['compare', 'vs', 'versus', 'difference', 'better']):
            focus['question_type'] = 'comparison'
            focus['is_comparison'] = True
        elif any(word in query_lower for word in ['recommend', 'suggest', 'should i', 'best way']):
            focus['question_type'] = 'recommendation'
            focus['is_recommendation'] = True
        elif '?' in query:
            focus['question_type'] = 'question'
        
        # Extract specific aspects mentioned
        aspects = []
        aspect_keywords = {
            'cost': ['cost', 'price', 'expense', 'bill', 'charge'],
            'performance': ['performance', 'speed', 'latency', 'throughput'],
            'security': ['security', 'compliance', 'encryption', 'access'],
            'scalability': ['scale', 'scaling', 'elastic', 'auto-scale'],
            'availability': ['availability', 'uptime', 'reliability', 'fault']
        }
        
        for aspect, keywords in aspect_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                aspects.append(aspect)
        
        focus['specific_aspects'] = aspects
        return focus
    
    def _needs_data_analysis(self, query: str) -> bool:
        """Check if query requires actual billing data analysis"""
        data_analysis_keywords = [
            'my costs', 'my spending', 'my usage', 'analyze my', 'my bills',
            'current costs', 'total spending', 'breakdown', 'dashboard',
            'show me', 'what am i spending', 'cost analysis'
        ]
        
        return any(keyword in query for keyword in data_analysis_keywords)

def create_enhanced_prompt(query: str, analysis: Dict[str, Any], available_data: Dict[str, Any] = None) -> str:
    """Create an enhanced prompt for multi-cloud FinOps responses"""
    
    base_context = f"""
You are a FinOps expert providing advice for multi-cloud environments (GCP, AWS, Azure).

USER QUERY: "{query}"

QUERY ANALYSIS:
- Target Clouds: {analysis['target_clouds'] if analysis['target_clouds'] else 'All clouds (multi-cloud response)'}
- Primary Topic: {analysis['primary_topic']}
- Response Scope: {analysis['response_scope']}
- Question Focus: {analysis['question_focus']['question_type']}

RESPONSE GUIDELINES:
1. SCOPE: {"Provide cloud-specific advice for " + ", ".join(analysis['target_clouds']) if analysis['target_clouds'] else "Provide generic multi-cloud advice covering GCP, AWS, and Azure"}
2. FOCUS: Be specific and directly answer the question asked
3. FORMAT: Keep response concise and actionable
4. CONTEXT: Include relevant examples from multiple cloud providers unless specifically asked about one
"""

    if analysis['requires_data_analysis'] and available_data:
        base_context += f"""
5. DATA ANALYSIS: User has billing data available - include specific insights:
   - Total multi-cloud spending: ${available_data.get('total_cost', 0):,.2f}
   - Active providers: {list(available_data.get('cost_breakdown', {}).keys())}
"""

    if analysis['question_focus']['is_how_to']:
        base_context += "\n6. STRUCTURE: Provide step-by-step guidance with actionable recommendations"
    elif analysis['question_focus']['is_what_is']:
        base_context += "\n6. STRUCTURE: Provide clear definition with practical examples"
    elif analysis['question_focus']['is_comparison']:
        base_context += "\n6. STRUCTURE: Compare options clearly with pros/cons for each cloud"
    elif analysis['question_focus']['is_recommendation']:
        base_context += "\n6. STRUCTURE: Give specific recommendations with rationale"

    base_context += "\n\nProvide a focused, specific answer that directly addresses the user's question."
    
    return base_context

# Example usage and testing
if __name__ == "__main__":
    processor = EnhancedQueryProcessor()
    
    # Test queries
    test_queries = [
        "How do I reduce costs?",  # Should be multi-cloud
        "What are AWS EC2 best practices?",  # Should be AWS-specific  
        "Compare storage costs across clouds",  # Should be multi-cloud comparative
        "How to optimize my current spending?",  # Should use data analysis
        "What is FinOps governance?",  # Should be multi-cloud definition
    ]
    
    for query in test_queries:
        print(f"\n🔍 Query: {query}")
        analysis = processor.analyze_query(query)
        print(f"📊 Analysis: {analysis}")
        
        prompt = create_enhanced_prompt(query, analysis)
        print(f"📝 Enhanced Prompt Preview: {prompt[:200]}...")