import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import Dict, List, Any
import streamlit as st

class VisualizationUtils:
    @staticmethod
    def create_cost_pie_chart(data: Dict[str, float], title: str = "Cost Breakdown"):
        """Create a pie chart for cost breakdown"""
        if not data:
            return None
        
        labels = list(data.keys())
        values = list(data.values())
        
        fig = go.Figure(data=[go.Pie(labels=labels, values=values, hole=0.3)])
        fig.update_layout(
            title=title,
            showlegend=True,
            height=400
        )
        return fig
    
    @staticmethod
    def create_cost_bar_chart(data: Dict[str, float], title: str = "Cost Analysis", orientation: str = "vertical"):
        """Create a bar chart for cost analysis"""
        if not data:
            return None
        
        labels = list(data.keys())
        values = list(data.values())
        
        if orientation == "horizontal":
            fig = go.Figure([go.Bar(y=labels, x=values, orientation='h')])
            fig.update_layout(height=max(400, len(labels) * 30))
        else:
            fig = go.Figure([go.Bar(x=labels, y=values)])
            fig.update_layout(height=400)
        
        fig.update_layout(
            title=title,
            showlegend=False,
            xaxis_tickangle=-45 if orientation == "vertical" else 0
        )
        return fig
    
    @staticmethod
    def create_trend_chart(trend_data: Dict[str, Any], title: str = "Cost Trends"):
        """Create a line chart for cost trends"""
        if 'daily_costs' not in trend_data or not trend_data['daily_costs']:
            return None
        
        dates = list(trend_data['daily_costs'].keys())
        costs = list(trend_data['daily_costs'].values())
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=dates, y=costs, mode='lines+markers', name='Daily Cost'))
        
        fig.update_layout(
            title=title,
            xaxis_title="Date",
            yaxis_title="Cost",
            height=400
        )
        return fig
    
    @staticmethod
    def create_top_services_chart(top_services: List[Dict[str, Any]], title: str = "Top Services by Cost"):
        """Create a horizontal bar chart for top services"""
        if not top_services:
            return None
        
        services = [item['service'] for item in top_services]
        costs = [item['cost'] for item in top_services]
        
        fig = go.Figure([go.Bar(y=services, x=costs, orientation='h')])
        fig.update_layout(
            title=title,
            height=max(400, len(services) * 30),
            yaxis={'categoryorder': 'total ascending'}
        )
        return fig
    
    @staticmethod
    def display_metrics(insights: Dict[str, Any]):
        """Display key metrics in Streamlit"""
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_cost = insights.get('total_cost', 0)
            st.metric("Total Cost", f"${total_cost:,.2f}")
        
        with col2:
            avg_cost = insights.get('avg_daily_cost', 0)
            st.metric("Avg Daily Cost", f"${avg_cost:,.2f}")
        
        with col3:
            service_count = len(insights.get('service_breakdown', {}))
            st.metric("Services", service_count)
        
        with col4:
            project_count = len(insights.get('project_breakdown', {}))
            st.metric("Projects", project_count)
    
    @staticmethod
    def display_recommendations(recommendations: List[str]):
        """Display recommendations in an organized way"""
        if not recommendations:
            st.info("No specific recommendations available.")
            return
        
        st.subheader("💡 Cost Optimization Recommendations")
        for i, rec in enumerate(recommendations, 1):
            st.write(f"{i}. {rec}")
    
    @staticmethod
    def create_summary_dashboard(insights: Dict[str, Any]):
        """Create a comprehensive dashboard"""
        st.header("📊 FinOps Dashboard")
        
        # Display key metrics
        VisualizationUtils.display_metrics(insights)
        
        st.divider()
        
        # Create visualizations in columns
        col1, col2 = st.columns(2)
        
        with col1:
            # Service breakdown pie chart
            service_data = insights.get('service_breakdown', {})
            if service_data:
                fig_pie = VisualizationUtils.create_cost_pie_chart(service_data, "Cost by Service")
                if fig_pie:
                    st.plotly_chart(fig_pie, use_container_width=True)
        
        with col2:
            # Project breakdown bar chart
            project_data = insights.get('project_breakdown', {})
            if project_data:
                fig_bar = VisualizationUtils.create_cost_bar_chart(project_data, "Cost by Project")
                if fig_bar:
                    st.plotly_chart(fig_bar, use_container_width=True)
        
        # Top services chart
        top_services = insights.get('top_cost_services', [])
        if top_services:
            st.subheader("🔝 Top Services by Cost")
            fig_top = VisualizationUtils.create_top_services_chart(top_services)
            if fig_top:
                st.plotly_chart(fig_top, use_container_width=True)
        
        # Cost trends
        cost_trends = insights.get('cost_trends', {})
        if cost_trends and 'daily_costs' in cost_trends:
            st.subheader("📈 Cost Trends")
            fig_trend = VisualizationUtils.create_trend_chart(cost_trends)
            if fig_trend:
                st.plotly_chart(fig_trend, use_container_width=True)
        
        # Recommendations
        recommendations = insights.get('recommendations', [])
        if recommendations:
            st.divider()
            VisualizationUtils.display_recommendations(recommendations)