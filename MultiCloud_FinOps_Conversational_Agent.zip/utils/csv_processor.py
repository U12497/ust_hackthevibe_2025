import pandas as pd
import numpy as np
import glob
import os
from typing import Dict, List, Any, Optional
import streamlit as st
from datetime import datetime, timedelta

class CSVProcessor:
    def __init__(self):
        self.df = None
        self.processed_data = {}
    
    def load_csv_files(self, csv_directory: str) -> Optional[pd.DataFrame]:
        """Load and combine all CSV files from directory"""
        csv_files = glob.glob(os.path.join(csv_directory, "*.csv"))
        
        if not csv_files:
            st.warning(f"No CSV files found in {csv_directory}")
            return None
        
        dataframes = []
        for csv_file in csv_files:
            try:
                df = pd.read_csv(csv_file)
                df['source_file'] = os.path.basename(csv_file)
                # Standardize columns BEFORE concatenating to prevent duplicates
                df = self.standardize_columns(df)
                dataframes.append(df)
            except Exception as e:
                st.error(f"Error loading {csv_file}: {str(e)}")
        
        if dataframes:
            combined_df = pd.concat(dataframes, ignore_index=True)
            self.df = combined_df
            return combined_df
        return None
    
    def standardize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardize column names for GCP billing data"""
        # Common column mappings for GCP billing exports
        column_mapping = {
            # Standard GCP export format
            'service.description': 'Service',
            'sku.description': 'SKU',
            'project.name': 'Project',
            'cost': 'Cost',
            'usage.amount': 'Usage',
            'location.location': 'Location',
            'export_time': 'Date',
            'usage_start_time': 'Usage_Start',
            'usage_end_time': 'Usage_End',
            'credits.amount': 'Credits',
            'currency': 'Currency',
            
            # User's specific CSV format (GCP)
            'Service Name': 'Service',
            'Resource ID': 'Resource_ID',
            'Usage Quantity': 'Usage',
            'Usage Unit': 'Usage_Unit',
            'Region/Zone': 'Location',
            'Usage Start Date': 'Usage_Start',
            'Usage End Date': 'Usage_End',
            'Cost per Quantity ($)': 'Unit_Cost',
            'Unrounded Cost ($)': 'Unrounded_Cost',
            'Rounded Cost ($)': 'Cost_USD',
            'Total Cost (INR)': 'Cost',  # Use INR as primary cost column
            'CPU Utilization (%)': 'CPU_Utilization',
            'Memory Utilization (%)': 'Memory_Utilization',
            
            # AWS format mappings
            'Region': 'Location',  # AWS uses 'Region' for location
            'Unblended Cost': 'Cost',  # AWS cost column
            'Blended Cost': 'Blended_Cost',
            'Unblended Rate': 'Rate',
            
            # Azure format mappings  
            'Location': 'Location',  # Azure already uses 'Location'
            'Pre-Tax Cost': 'Cost',  # Azure cost column
            'Resource Rate': 'Rate',
            'Meter Category': 'Category',
            'Meter Subcategory': 'Subcategory'
        }
        
        # Rename columns if they exist and handle currency conversion
        df_standardized = df.copy()
        
        # First pass: rename columns
        for old_name, new_name in column_mapping.items():
            if old_name in df_standardized.columns:
                df_standardized = df_standardized.rename(columns={old_name: new_name})
        
        # Second pass: handle currency conversion for Cost column based on source
        if 'Cost' in df_standardized.columns and 'source_file' in df_standardized.columns:
            for source_file in df_standardized['source_file'].unique():
                file_mask = df_standardized['source_file'] == source_file
                
                if 'gcp' in source_file.lower():
                    # GCP costs are in INR, convert to USD (assuming 1 USD = 83 INR)
                    df_standardized.loc[file_mask, 'Cost'] = pd.to_numeric(df_standardized.loc[file_mask, 'Cost'], errors='coerce') / 83
                else:
                    # AWS and Azure costs are already in USD
                    df_standardized.loc[file_mask, 'Cost'] = pd.to_numeric(df_standardized.loc[file_mask, 'Cost'], errors='coerce')
        
        return df_standardized
    
    def process_billing_data(self) -> Dict[str, Any]:
        """Process billing data and generate insights"""
        if self.df is None:
            return {}
        
        df = self.standardize_columns(self.df)
        
        # Ensure Cost column is numeric (currency conversion already handled in standardization)
        if 'Cost' in df.columns:
            df['Cost'] = pd.to_numeric(df['Cost'], errors='coerce')
        
        # Remove rows with null costs
        df = df.dropna(subset=['Cost'])
        
        insights = {
            'total_cost': df['Cost'].sum(),
            'avg_daily_cost': df['Cost'].sum() / max(1, len(df['Cost'].dropna())),
            'service_breakdown': self._get_service_breakdown(df),
            'project_breakdown': self._get_project_breakdown(df),
            'location_breakdown': self._get_location_breakdown(df),
            'top_cost_services': self._get_top_services(df),
            'cost_trends': self._get_cost_trends(df),
            'recommendations': self._generate_recommendations(df),
            'raw_data': df
        }
        
        self.processed_data = insights
        return insights
    
    def _get_service_breakdown(self, df: pd.DataFrame) -> Dict[str, float]:
        """Get cost breakdown by service"""
        cost_cols = ['Cost', 'Cost_INR', 'Total Cost (INR)', 'Cost_USD']
        
        if 'Service' in df.columns:
            # Find available cost column
            for cost_col in cost_cols:
                if cost_col in df.columns:
                    try:
                        df_copy = df.copy()
                        df_copy[cost_col] = pd.to_numeric(df_copy[cost_col], errors='coerce')
                        df_copy = df_copy.dropna(subset=['Service', cost_col])
                        return df_copy.groupby('Service')[cost_col].sum().to_dict()
                    except Exception as e:
                        print(f"Error in service breakdown: {e}")
                        continue
        return {}
    
    def _get_project_breakdown(self, df: pd.DataFrame) -> Dict[str, float]:
        """Get cost breakdown by project"""
        cost_cols = ['Cost', 'Cost_INR', 'Total Cost (INR)', 'Cost_USD']
        
        if 'Project' in df.columns:
            # Find available cost column
            for cost_col in cost_cols:
                if cost_col in df.columns:
                    try:
                        df_copy = df.copy()
                        df_copy[cost_col] = pd.to_numeric(df_copy[cost_col], errors='coerce')
                        df_copy = df_copy.dropna(subset=['Project', cost_col])
                        return df_copy.groupby('Project')[cost_col].sum().to_dict()
                    except Exception as e:
                        print(f"Error in project breakdown: {e}")
                        continue
        return {}
    
    def _get_location_breakdown(self, df: pd.DataFrame) -> Dict[str, float]:
        """Get cost breakdown by location"""
        # Check for various location column names
        location_cols = ['Location', 'Region/Zone', 'Region', 'Zone']
        cost_cols = ['Cost', 'Cost_INR', 'Total Cost (INR)', 'Cost_USD']
        
        location_col = None
        cost_col = None
        
        # Find available location column
        for col in location_cols:
            if col in df.columns:
                location_col = col
                break
                
        # Find available cost column  
        for col in cost_cols:
            if col in df.columns:
                cost_col = col
                break
                
        if location_col and cost_col:
            try:
                # Ensure the cost column is numeric and handle any non-numeric values
                df_copy = df.copy()
                df_copy[cost_col] = pd.to_numeric(df_copy[cost_col], errors='coerce')
                df_copy = df_copy.dropna(subset=[location_col, cost_col])
                
                # Group by location and sum costs
                result = df_copy.groupby(location_col)[cost_col].sum().to_dict()
                return result
            except Exception as e:
                print(f"Error in location breakdown: {e}")
                # Return available columns for debugging
                print(f"Available columns: {list(df.columns)}")
                return {}
        
        print(f"Location or cost column not found. Available columns: {list(df.columns)}")
        return {}
    
    def _get_top_services(self, df: pd.DataFrame, top_n: int = 10) -> List[Dict[str, Any]]:
        """Get top N services by cost"""
        if 'Service' not in df.columns:
            return []
        
        top_services = df.groupby('Service')['Cost'].sum().nlargest(top_n)
        return [{'service': service, 'cost': cost} for service, cost in top_services.items()]
    
    def _get_cost_trends(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze cost trends over time"""
        trends = {}
        
        # Try to find date columns
        date_columns = [col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()]
        
        if date_columns:
            try:
                df['parsed_date'] = pd.to_datetime(df[date_columns[0]], errors='coerce')
                if not df['parsed_date'].isna().all():
                    daily_costs = df.groupby(df['parsed_date'].dt.date)['Cost'].sum()
                    trends['daily_costs'] = daily_costs.to_dict()
                    trends['trend_direction'] = 'increasing' if daily_costs.iloc[-1] > daily_costs.iloc[0] else 'decreasing'
            except Exception as e:
                st.warning(f"Could not parse dates: {str(e)}")
        
        return trends
    
    def _generate_recommendations(self, df: pd.DataFrame) -> List[str]:
        """Generate cost optimization recommendations"""
        recommendations = []
        
        total_cost = df['Cost'].sum()
        
        if 'Service' in df.columns:
            service_costs = df.groupby('Service')['Cost'].sum()
            top_service = service_costs.idxmax()
            top_service_cost = service_costs.max()
            top_service_percentage = (top_service_cost / total_cost) * 100
            
            if top_service_percentage > 50:
                recommendations.append(f"🔍 {top_service} accounts for {top_service_percentage:.1f}% of total costs. Consider optimizing this service first.")
        
        if 'Project' in df.columns:
            project_costs = df.groupby('Project')['Cost'].sum()
            if len(project_costs) > 1:
                top_project = project_costs.idxmax()
                recommendations.append(f"💡 Project '{top_project}' has the highest costs. Review resource usage and consider rightsizing.")
        
        # Generic recommendations
        recommendations.extend([
            "📊 Implement cost monitoring alerts to track spending trends",
            "🏷️ Use resource labeling for better cost attribution",
            "⏰ Schedule non-production resources to reduce costs",
            "🔄 Consider committed use discounts for predictable workloads",
            "🗂️ Regular review of unused or underutilized resources"
        ])
        
        return recommendations
    
    def get_summary_stats(self) -> Dict[str, Any]:
        """Get summary statistics"""
        if self.df is None:
            return {}
        
        df = self.standardize_columns(self.df)
        
        return {
            'total_records': len(df),
            'total_cost': df['Cost'].sum() if 'Cost' in df.columns else 0,
            'date_range': self._get_date_range(df),
            'unique_services': df['Service'].nunique() if 'Service' in df.columns else 0,
            'unique_projects': df['Project'].nunique() if 'Project' in df.columns else 0,
        }
    
    def _get_date_range(self, df: pd.DataFrame) -> Dict[str, str]:
        """Get date range from data"""
        date_columns = [col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()]
        
        if date_columns:
            try:
                dates = pd.to_datetime(df[date_columns[0]], errors='coerce')
                valid_dates = dates.dropna()
                if not valid_dates.empty:
                    return {
                        'start': valid_dates.min().strftime('%Y-%m-%d'),
                        'end': valid_dates.max().strftime('%Y-%m-%d')
                    }
            except Exception:
                pass
        
        return {'start': 'Unknown', 'end': 'Unknown'}