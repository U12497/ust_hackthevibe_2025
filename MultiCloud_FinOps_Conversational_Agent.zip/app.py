import streamlit as st
import os
from dotenv import load_dotenv
import pandas as pd
from pathlib import Path

# Load environment variables
load_dotenv()

# Import our custom modules
from utils.document_loader import DocumentLoader
from utils.csv_processor import CSVProcessor
from utils.visualizations import VisualizationUtils
from agents.finops_rag_agent import FinOpsRAGAgent
from agents.gcp_billing_agent import GCPBillingAgent
from agents.multi_agent_system import MultiAgentFinOpsSystem

# Page configuration
st.set_page_config(
    page_title="FinOps Multi-Agent System for GCP, AWS and AZURE",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        color: #1f77b4;
        margin-bottom: 2rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #333;
        margin: 1rem 0;
    }
    .metric-container {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .chat-message {
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
        background-color: #f8f9fa;
    }
    .recommendation-box {
        background-color: #e8f5e8;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #28a745;
        margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)

def initialize_session_state():
    """Initialize session state variables"""
    if "document_loader" not in st.session_state:
        st.session_state.document_loader = None
    if "csv_processor" not in st.session_state:
        st.session_state.csv_processor = None
    if "finops_agent" not in st.session_state:
        st.session_state.finops_agent = None
    if "billing_agent" not in st.session_state:
        st.session_state.billing_agent = None
    if "multi_agent_system" not in st.session_state:
        st.session_state.multi_agent_system = None
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "billing_insights" not in st.session_state:
        st.session_state.billing_insights = None
    if "multi_cloud_costs" not in st.session_state:
        st.session_state.multi_cloud_costs = None
    if "system_initialized" not in st.session_state:
        st.session_state.system_initialized = False

def check_google_cloud_config():
    """Check if Google Cloud configuration is available"""
    project = os.getenv("GOOGLE_CLOUD_PROJECT")
    if not project or project == "your_project_id_here":
        st.error("⚠️ Google Cloud Project ID not found! Please set your GOOGLE_CLOUD_PROJECT in the .env file.")
        st.info("💡 Create a .env file and add: GOOGLE_CLOUD_PROJECT=your_actual_project_id")
        return False
    
    # Check if authenticated with gcloud CLI or service account
    try:
        import google.auth
        credentials, project_from_creds = google.auth.default()
        st.success(f"✅ Authenticated with Google Cloud Project: {project_from_creds or project}")
        return True
    except Exception as e:
        st.error(f"⚠️ Google Cloud authentication failed: {str(e)}")
        st.info("""
        💡 To authenticate:
        1. Install Google Cloud CLI: https://cloud.google.com/sdk/docs/install
        2. Run: `gcloud auth application-default login`
        3. Or set GOOGLE_APPLICATION_CREDENTIALS to your service account key file
        """)
        return False

def initialize_system():
    """Initialize the multi-agent system"""
    try:
        with st.spinner("🚀 Initializing FinOps Multi-Agent System..."):
            # Initialize document loader
            st.session_state.document_loader = DocumentLoader()
            
            # Load PDFs from data/pdfs directory
            pdf_dir = Path("data/pdfs")
            vectorstore = st.session_state.document_loader.load_and_index_documents(str(pdf_dir))
            
            # Initialize agents
            st.session_state.finops_agent = FinOpsRAGAgent(vectorstore)
            st.session_state.billing_agent = GCPBillingAgent()
            st.session_state.csv_processor = CSVProcessor()
            
            # Initialize cloud-specific agents
            from agents.aws_finops_agent import AWSFinOpsAgent
            from agents.azure_finops_agent import AzureFinOpsAgent
            
            # Initialize AWS and Azure agents
            st.session_state.aws_agent = AWSFinOpsAgent()
            st.session_state.azure_agent = AzureFinOpsAgent()
            
            # Initialize multi-agent system with all agents
            st.session_state.multi_agent_system = MultiAgentFinOpsSystem(
                st.session_state.finops_agent,
                st.session_state.billing_agent,
                st.session_state.aws_agent,
                st.session_state.azure_agent
            )
            
            st.session_state.system_initialized = True
            st.success("✅ System initialized successfully!")
            
            # Auto-load billing data if available
            csv_dir = Path("data/csv")
            if csv_dir.exists() and list(csv_dir.glob("*.csv")):
                st.info("📊 Auto-loading multi-cloud billing data...")
                billing_insights = load_billing_data()
                
                # Immediately calculate and cache multi-cloud costs for sidebar display
                if billing_insights or st.session_state.aws_agent or st.session_state.azure_agent:
                    total_cost, cost_breakdown = get_combined_cloud_costs()
                    st.session_state.multi_cloud_costs = {
                        'total_cost': total_cost,
                        'cost_breakdown': cost_breakdown
                    }
                    
                    if total_cost > 0:
                        # Display detailed multi-cloud cost breakdown during initialization
                        st.success("💰 Multi-cloud billing data loaded successfully!")
                        
                        # Create a nice formatted display of the cost breakdown
                        st.markdown("### 🌐 Multi-Cloud Total Cost")
                        st.markdown(f"# ${total_cost:,.2f}")
                        
                        st.markdown("**Cost Breakdown:**")
                        
                        # Display each provider with emoji and percentage
                        for provider, cost in cost_breakdown.items():
                            if cost > 0:
                                percentage = (cost / total_cost * 100) if total_cost > 0 else 0
                                
                                # Choose emoji based on provider
                                emoji = "☁️"
                                if provider == "GCP":
                                    emoji = "🟦"  # Google blue
                                elif provider == "AWS": 
                                    emoji = "🟧"  # AWS orange
                                elif provider == "Azure":
                                    emoji = "🟦"  # Azure blue
                                
                                st.markdown(f"**{emoji} {provider}**: ${cost:,.2f} ({percentage:.1f}%)")
                        
                        # Show summary info
                        active_providers = len([k for k, v in cost_breakdown.items() if v > 0])
                        st.info(f"📊 {active_providers} cloud providers active • Total spending: ${total_cost:,.2f}")
                        
                    else:
                        st.warning("⚠️ Billing data found but no costs calculated")
                else:
                    st.info("📂 No billing data found in data/csv directory")
            
    except Exception as e:
        st.error(f"❌ Error initializing system: {str(e)}")
        st.info("💡 Make sure you have installed all required packages: pip install -r requirements.txt")

def get_combined_cloud_costs():
    """Calculate combined costs from all cloud providers"""
    total_cost = 0
    cost_breakdown = {}
    
    # GCP costs from CSV processor
    if st.session_state.billing_insights:
        gcp_cost = st.session_state.billing_insights.get('total_cost', 0)
        total_cost += gcp_cost
        cost_breakdown['GCP'] = gcp_cost
    
    # AWS costs from AWS agent
    if st.session_state.aws_agent and hasattr(st.session_state.aws_agent, 'billing_data') and st.session_state.aws_agent.billing_data is not None:
        try:
            aws_analysis = st.session_state.aws_agent.analyze_aws_billing()
            aws_cost = aws_analysis.get('total_cost', 0)
            total_cost += aws_cost
            cost_breakdown['AWS'] = aws_cost
        except Exception:
            cost_breakdown['AWS'] = 0
    
    # Azure costs from Azure agent  
    if st.session_state.azure_agent and hasattr(st.session_state.azure_agent, 'billing_data') and st.session_state.azure_agent.billing_data is not None:
        try:
            azure_analysis = st.session_state.azure_agent.analyze_azure_billing()
            azure_cost = azure_analysis.get('total_cost', 0)
            total_cost += azure_cost
            cost_breakdown['Azure'] = azure_cost
        except Exception:
            cost_breakdown['Azure'] = 0
    
    return total_cost, cost_breakdown

def load_billing_data():
    """Load and process multi-cloud billing data"""
    csv_dir = Path("data/csv")
    
    if not csv_dir.exists() or not list(csv_dir.glob("*.csv")):
        st.warning("📂 No CSV files found in data/csv directory. Please add your billing CSV files.")
        return None
    
    try:
        with st.spinner("📊 Loading multi-cloud billing data..."):
            # Load CSV files and determine cloud platform
            csv_files = list(csv_dir.glob("*.csv"))
            
            # Load GCP data
            gcp_files = [f for f in csv_files if 'gcp' in f.name.lower() or 'google' in f.name.lower()]
            if gcp_files:
                df = st.session_state.csv_processor.load_csv_files(str(csv_dir))
                if df is not None:
                    insights = st.session_state.csv_processor.process_billing_data()
                    st.session_state.billing_insights = insights
                    st.success(f"✅ Loaded GCP billing data: {len(df)} records")
            
            # Load AWS data
            aws_files = [f for f in csv_files if 'aws' in f.name.lower() or 'amazon' in f.name.lower()]
            if aws_files and st.session_state.aws_agent:
                for aws_file in aws_files:
                    st.session_state.aws_agent.load_billing_data(str(aws_file))
                    st.success(f"✅ Loaded AWS billing data from {aws_file.name}")
            
            # Load Azure data
            azure_files = [f for f in csv_files if 'azure' in f.name.lower() or 'microsoft' in f.name.lower()]
            if azure_files and st.session_state.azure_agent:
                for azure_file in azure_files:
                    st.session_state.azure_agent.load_billing_data(str(azure_file))
                    st.success(f"✅ Loaded Azure billing data from {azure_file.name}")
            
            # Update cached multi-cloud costs after loading all data
            total_cost, cost_breakdown = get_combined_cloud_costs()
            st.session_state.multi_cloud_costs = {
                'total_cost': total_cost,
                'cost_breakdown': cost_breakdown
            }
            
            return st.session_state.billing_insights
            
    except Exception as e:
        st.error(f"❌ Error loading billing data: {str(e)}")
        return None

def main():
    """Main application function"""
    initialize_session_state()
    
    # Header
    st.markdown('<h1 class="main-header">💰 FinOps Multi-Agent System for GCP, AWS and AZURE</h1>', unsafe_allow_html=True)    
    
    # Check Google Cloud configuration
    if not check_google_cloud_config():
        return
    
    # Sidebar
    with st.sidebar:
        st.header("🛠️ System Control")
        
        # System initialization
        if not st.session_state.system_initialized:
            if st.button("🚀 Initialize System", type="primary"):
                initialize_system()
        else:
            st.success("✅ System Ready")
            
            # Data loading section
            st.header("📊 Data Management")
            
            if st.button("📂 Load Billing Data"):
                load_billing_data()
            
            # Show multi-cloud cost status (using cached data from initialization)
            if hasattr(st.session_state, 'multi_cloud_costs') and st.session_state.multi_cloud_costs:
                st.success("✅ Billing Data Loaded")
                
                # Use cached multi-cloud costs from initialization
                total_cost = st.session_state.multi_cloud_costs['total_cost']
                cost_breakdown = st.session_state.multi_cloud_costs['cost_breakdown']
                
                # Display total combined cost
                st.metric("🌐 Multi-Cloud Total Cost", f"${total_cost:,.2f}")
                
                # Show breakdown by cloud provider
                if cost_breakdown:
                    st.write("**Cost Breakdown:**")
                    for provider, cost in cost_breakdown.items():
                        if cost > 0:
                            percentage = (cost / total_cost * 100) if total_cost > 0 else 0
                            st.write(f"☁️ {provider}: ${cost:,.2f} ({percentage:.1f}%)")
            
            # Fallback: Show basic billing status if costs not cached
            elif st.session_state.billing_insights or (st.session_state.aws_agent and hasattr(st.session_state.aws_agent, 'billing_data')) or (st.session_state.azure_agent and hasattr(st.session_state.azure_agent, 'billing_data')):
                st.success("✅ Billing Data Available")
                if st.button("🔄 Refresh Cost Display"):
                    total_cost, cost_breakdown = get_combined_cloud_costs()
                    st.session_state.multi_cloud_costs = {
                        'total_cost': total_cost,
                        'cost_breakdown': cost_breakdown
                    }
                    st.rerun()
            
            # Chat Management
            st.header("💬 Chat Controls")
            if st.button("🧹 Clear Chat History", help="Clear all chat messages"):
                st.session_state.chat_history = []
                st.success("✅ Chat history cleared!")
                st.rerun()
            
            if st.session_state.chat_history:
                st.write(f"📝 Messages: {len(st.session_state.chat_history)}")
            
            # System capabilities
            st.header("🎯 Capabilities")
            capabilities = [
                "💡 FinOps Expert Q&A",
                "📈 Multi-Cloud Billing Analysis",
                "☁️ GCP + AWS + Azure Support", 
                "🔍 Cost Optimization",
                "📊 Visual Dashboards",
                "🤖 Multi-Agent Coordination"
            ]
            for cap in capabilities:
                st.write(cap)
    
    # Main content area
    if not st.session_state.system_initialized:
        st.info("👆 Please initialize the system using the sidebar to get started.")
        
        # Show setup instructions
        st.header("📋 Setup Instructions")
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📄 FinOps KB Articles")
            st.write("Place your FinOps KB articles in:")
            st.code("data/pdfs/")
            st.info("These documents will be used to build the knowledge base for FinOps questions.")
        
        with col2:
            st.subheader("📊 Cloud Billing Data for GCP, AWS and AZURE")
            st.write("Place your cloud billing CSV files in:")
            st.code("data/csv/")
            st.info("These files will be analyzed for cost insights and recommendations.")
        
        return
    
    # Main application tabs
    tab1, tab2, tab3 = st.tabs(["💬 Chat Interface", "📊 Billing Dashboard", "🔧 Settings"])
    
    with tab1:
        st.header("💬 Chat with FinOps Expert")
        
        # Sample questions
        st.subheader("💡 Sample Questions")
        sample_questions = [
            "What is FinOps and why is it important?",
            "How can I optimize my cloud costs?",
            "Analyze my GCP billing data",
            "What are the best practices for cost allocation?",
            "Explain reserved instances vs on-demand pricing",
            "How do I implement cost monitoring and alerting?"
        ]
        
        cols = st.columns(3)
        for i, question in enumerate(sample_questions):
            with cols[i % 3]:
                if st.button(question, key=f"sample_{i}"):
                    st.session_state.current_query = question
        
        # Chat input section
        st.subheader("💬 Ask Your FinOps Question")
        user_query = st.chat_input("💡 Ask me anything about FinOps or request billing data analysis...")
        
        if "current_query" in st.session_state:
            user_query = st.session_state.current_query
            del st.session_state.current_query
        
        # Process query
        if user_query:
            from datetime import datetime
            timestamp = datetime.now().strftime("%H:%M:%S")
            
            # Add user message to chat
            st.session_state.chat_history.append({
                "role": "user", 
                "content": user_query,
                "timestamp": timestamp
            })
            
            # Process with multi-agent system
            with st.spinner("🤔 Thinking..."):
                result = st.session_state.multi_agent_system.process_query(
                    user_query, 
                    st.session_state.billing_insights
                )
            
            # Add assistant response
            response_timestamp = datetime.now().strftime("%H:%M:%S")
            st.session_state.chat_history.append({
                "role": "assistant", 
                "content": result["response"],
                "details": result,
                "timestamp": response_timestamp
            })
            
            # Auto-scroll to top (rerun to show latest message first)
            st.rerun()
        
        # Display chat history (newest first)
        if st.session_state.chat_history:
            st.write(f"💬 **Conversation History** ({len(st.session_state.chat_history)} messages)")
            
            # Reverse the chat history to show newest messages first
            for message in reversed(st.session_state.chat_history):
                with st.chat_message(message["role"]):
                    # Add timestamp if available
                    if "timestamp" in message:
                        st.caption(f"🕒 {message['timestamp']}")
                    
                    st.write(message["content"])
                    
                    # Show additional details for assistant messages
                    if message["role"] == "assistant" and "details" in message:
                        details = message["details"]
                        
                        # Show sources if available
                        if details.get("sources"):
                            with st.expander("📚 Sources"):
                                st.write(", ".join(details["sources"]))
                        
                        # Show query type
                        if details.get("query_type"):
                            st.caption(f"🔄 Query Type: {details['query_type']}")
        else:
            st.info("💬 Start a conversation by asking a question below!")
    
    with tab2:
        st.header("📊 Multi-Cloud Billing Dashboard")
        
        # Multi-cloud overview
        cloud_tabs = st.tabs(["🌐 Overview", "🔵 GCP", "🟠 AWS", "🔷 Azure"])
        
        with cloud_tabs[0]:  # Overview tab
            st.subheader("🌐 Multi-Cloud Cost Overview")
            
            # Show which clouds have data
            col1, col2, col3 = st.columns(3)
            
            with col1:
                gcp_status = "✅ Data Loaded" if st.session_state.billing_insights else "❌ No Data"
                st.metric("🔵 GCP Status", gcp_status)
            
            with col2:
                aws_status = "✅ Data Loaded" if (hasattr(st.session_state, 'aws_agent') and 
                                                st.session_state.aws_agent and 
                                                st.session_state.aws_agent.billing_data is not None) else "❌ No Data"
                st.metric("🟠 AWS Status", aws_status)
            
            with col3:
                azure_status = "✅ Data Loaded" if (hasattr(st.session_state, 'azure_agent') and 
                                                  st.session_state.azure_agent and 
                                                  st.session_state.azure_agent.billing_data is not None) else "❌ No Data"
                st.metric("🔷 Azure Status", azure_status)
            
            # Multi-cloud insights
            if st.session_state.billing_insights or aws_status == "✅ Data Loaded" or azure_status == "✅ Data Loaded":
                st.subheader("💡 Multi-Cloud Insights")
                st.info("💬 Ask questions like: 'Compare costs across all cloud platforms' or 'What are the optimization opportunities across clouds?'")
            else:
                st.info("📂 Load billing data from any cloud platform to see insights here.")
        
        with cloud_tabs[1]:  # GCP tab
            st.subheader("🔵 Google Cloud Platform")
            
            if st.session_state.billing_insights:
                VisualizationUtils.create_summary_dashboard(st.session_state.billing_insights)
                
                # Show raw data summary
                raw_data = st.session_state.billing_insights.get('raw_data')
                if raw_data is not None and not raw_data.empty:
                    st.divider()
                    st.subheader("📋 GCP Data Overview")
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.write("**Data Summary:**")
                        st.write(f"- Total Records: {len(raw_data):,}")
                        st.write(f"- Date Range: {raw_data['Usage_Start'].min() if 'Usage_Start' in raw_data.columns else 'N/A'} to {raw_data['Usage_End'].max() if 'Usage_End' in raw_data.columns else 'N/A'}")
                        st.write(f"- Unique Services: {raw_data['Service'].nunique() if 'Service' in raw_data.columns else 'N/A'}")
                        st.write(f"- Regions: {raw_data['Location'].nunique() if 'Location' in raw_data.columns else 'N/A'}")
                    
                    with col2:
                        st.write("**Available Columns:**")
                        for col in raw_data.columns:
                            st.write(f"- {col}")
                    
                    # Show sample data
                    st.subheader("📊 Sample Data")
                    st.dataframe(raw_data.head(10))
            else:
                st.info("📂 No GCP billing data loaded.")
        
        with cloud_tabs[2]:  # AWS tab
            st.subheader("🟠 Amazon Web Services")
            
            if (hasattr(st.session_state, 'aws_agent') and 
                st.session_state.aws_agent and 
                st.session_state.aws_agent.billing_data is not None):
                
                aws_analysis = st.session_state.aws_agent.analyze_aws_billing()
                
                if 'error' not in aws_analysis:
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("💰 Total Cost", f"${aws_analysis.get('total_cost', 0):.2f}")
                    with col2:
                        st.metric("📊 Total Records", aws_analysis.get('total_records', 0))
                    with col3:
                        st.metric("🛠️ Services", len(aws_analysis.get('service_breakdown', {})))
                    
                    # AWS-specific insights
                    if 'aws_insights' in aws_analysis:
                        st.subheader("💡 AWS Cost Optimization Insights")
                        insights = aws_analysis['aws_insights']
                        
                        for service, data in insights.items():
                            if isinstance(data, dict) and 'total_cost' in data:
                                with st.expander(f"� {service.upper()} - ${data['total_cost']:.2f}"):
                                    if 'potential_savings' in data:
                                        st.success(f"💵 Potential Monthly Savings: ${data['potential_savings']:.2f}")
                                    for key, value in data.items():
                                        if key != 'total_cost':
                                            st.write(f"**{key}**: {value}")
                    
                    # Show sample data
                    st.subheader("📊 AWS Sample Data")
                    st.dataframe(st.session_state.aws_agent.billing_data.head(10))
                else:
                    st.error(f"AWS Analysis Error: {aws_analysis['error']}")
            else:
                st.info("📂 No AWS billing data loaded. Add aws_billing_comprehensive.csv to data/csv/")
        
        with cloud_tabs[3]:  # Azure tab
            st.subheader("🔷 Microsoft Azure")
            
            if (hasattr(st.session_state, 'azure_agent') and 
                st.session_state.azure_agent and 
                st.session_state.azure_agent.billing_data is not None):
                
                azure_analysis = st.session_state.azure_agent.analyze_azure_billing()
                
                if 'error' not in azure_analysis:
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("💰 Total Cost", f"${azure_analysis.get('total_cost', 0):.2f}")
                    with col2:
                        st.metric("📊 Total Records", azure_analysis.get('total_records', 0))
                    with col3:
                        st.metric("🛠️ Services", len(azure_analysis.get('service_breakdown', {})))
                    
                    # Azure-specific insights
                    if 'azure_insights' in azure_analysis:
                        st.subheader("💡 Azure Cost Optimization Insights")
                        insights = azure_analysis['azure_insights']
                        
                        for service, data in insights.items():
                            if isinstance(data, dict) and 'total_cost' in data:
                                with st.expander(f"💰 {service.replace('_', ' ').title()} - ${data['total_cost']:.2f}"):
                                    for key, value in data.items():
                                        if key != 'total_cost' and 'savings' in key:
                                            st.success(f"💵 {key.replace('_', ' ').title()}: ${value:.2f}")
                                        elif key != 'total_cost':
                                            st.write(f"**{key}**: {value}")
                    
                    # Show sample data
                    st.subheader("📊 Azure Sample Data")
                    st.dataframe(st.session_state.azure_agent.billing_data.head(10))
                else:
                    st.error(f"Azure Analysis Error: {azure_analysis['error']}")
            else:
                st.info("📂 No Azure billing data loaded. Add azure_billing_comprehensive.csv to data/csv/")
    
    with tab3:
        st.header("🔧 System Configuration")
        
        # Google Cloud Configuration
        st.subheader("🔑 Google Cloud Configuration")
        project = os.getenv("GOOGLE_CLOUD_PROJECT")
        project_status = "✅ Configured" if project and project != "your_project_id_here" else "❌ Not Configured"
        st.write(f"GCP Project: {project_status}")
        if project and project != "your_project_id_here":
            st.write(f"Project ID: {project}")
        
        try:
            import google.auth
            _, _ = google.auth.default()
            st.write("Authentication: ✅ Configured")
        except:
            st.write("Authentication: ❌ Not Configured")
        
        # Data Directories
        st.subheader("📁 Data Directories")
        
        pdf_dir = Path("data/pdfs")
        csv_dir = Path("data/csv")
        
        col1, col2 = st.columns(2)
        with col1:
            pdf_count = len(list(pdf_dir.glob("*.pdf"))) if pdf_dir.exists() else 0
            st.metric("PDF Documents", pdf_count)
            
        with col2:
            csv_count = len(list(csv_dir.glob("*.csv"))) if csv_dir.exists() else 0
            st.metric("CSV Files", csv_count)
        
        # System Actions
        st.subheader("🔄 System Actions")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🔄 Reload Documents"):
                if st.session_state.system_initialized:
                    initialize_system()
        
        with col2:
            if st.button("🧹 Clear Chat History"):
                st.session_state.chat_history = []
                st.success("Chat history cleared!")
        
        with col3:
            if st.button("🔄 Reload Billing Data"):
                if st.session_state.system_initialized:
                    load_billing_data()
        
        # About section
        st.subheader("ℹ️ About")
        st.write("""
        This FinOps Multi-Agent System combines:
        - **RAG Agent**: Answers FinOps questions using your PDF knowledge base
        - **Billing Agent**: Analyzes GCP/AWS/Azure billing data for cost insights
        - **LangGraph Orchestration**: Coordinates multiple agents intelligently
        - **Streamlit Interface**: Provides an interactive user experience
        """)

if __name__ == "__main__":
    main()