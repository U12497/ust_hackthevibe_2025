"""
AWS FinOps Agent for cost optimization and billing analysis specific to AWS services.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
from langchain_google_vertexai import ChatVertexAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AWSFinOpsAgent:
    """AWS-specific FinOps agent for cost analysis and optimization recommendations."""
    
    def __init__(self, project_id: str = "ews-cde-djfp1-dev-npe-6b86"):
        """Initialize the AWS FinOps agent with Vertex AI."""
        self.project_id = project_id
        self.llm = ChatVertexAI(
            model_name="gemini-2.5-flash",
            project=project_id,
            temperature=0.1
        )
        self.billing_data = None
        
        # AWS-specific cost optimization prompts
        self.analysis_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert AWS FinOps analyst with deep knowledge of AWS services, pricing models, and cost optimization strategies.
            
            AWS-Specific Expertise:
            - EC2: Reserved Instances, Spot Instances, Right-sizing, Instance families
            - S3: Storage classes (Standard, IA, Glacier, Deep Archive), Lifecycle policies
            - RDS: Reserved Instances, Aurora Serverless, Read Replicas optimization
            - Lambda: Memory optimization, Provisioned Concurrency vs On-demand
            - EKS: Cluster autoscaling, Spot nodes, Fargate vs EC2 pricing
            - CloudFront: Regional edge caches, Origin optimization
            - EBS: gp3 vs gp2, IOPS optimization
            - Auto Scaling: Predictive scaling, Target tracking
            - AWS Cost Management: Cost Explorer, Budgets, Cost Anomaly Detection
            - Savings Plans vs Reserved Instances
            - AWS Well-Architected Framework cost optimization pillar
            
            Provide specific AWS recommendations with estimated savings percentages.
            """),
            ("user", "Analyze this AWS billing data and provide cost optimization recommendations:\n\n{billing_summary}")
        ])
        
        self.recommendation_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an AWS cost optimization expert. Provide detailed, actionable recommendations for AWS cost reduction.
            
            Focus on:
            1. AWS Reserved Instances and Savings Plans analysis
            2. EC2 right-sizing opportunities (CPU, memory utilization)
            3. S3 storage class optimization and lifecycle policies
            4. Lambda memory and timeout optimization
            5. RDS performance insights and Aurora migration
            6. EBS volume type optimization (gp2 to gp3)
            7. CloudFront cache optimization
            8. Auto Scaling group configuration
            9. Unused or underutilized resources
            10. Multi-AZ vs Single-AZ cost considerations
            
            Include specific AWS service recommendations and estimated monthly savings.
            """),
            ("user", "Service: {service_name}\nCost: ${cost:.2f}\nUsage Pattern: {usage_pattern}\n\nProvide specific AWS optimization recommendations:")
        ])

    def load_billing_data(self, csv_path: str) -> bool:
        """Load AWS billing data from CSV file."""
        try:
            self.billing_data = pd.read_csv(csv_path)
            
            # Standardize AWS CSV columns
            column_mapping = {
                'Service Name': 'Service',
                'Total Cost': 'Cost',
                'Unblended Cost': 'Cost',  # AWS billing export format
                'Blended Cost': 'BlendedCost',
                'Usage Quantity': 'Usage',
                'Resource ID': 'Resource',
                'Account ID': 'Account',
                'Usage Type': 'UsageType',
                'Region': 'Region'
            }
            
            for old_col, new_col in column_mapping.items():
                if old_col in self.billing_data.columns:
                    self.billing_data = self.billing_data.rename(columns={old_col: new_col})
            
            # Convert cost to numeric
            if 'Cost' in self.billing_data.columns:
                self.billing_data['Cost'] = pd.to_numeric(self.billing_data['Cost'], errors='coerce')
            
            logger.info(f"Successfully loaded AWS billing data with {len(self.billing_data)} records")
            return True
            
        except Exception as e:
            logger.error(f"Error loading AWS billing data: {str(e)}")
            return False

    def analyze_aws_billing(self) -> Dict:
        """Perform comprehensive AWS billing analysis."""
        if self.billing_data is None:
            return {"error": "No billing data loaded"}
        
        try:
            analysis = {}
            
            # Basic statistics
            total_cost = self.billing_data['Cost'].sum() if 'Cost' in self.billing_data.columns else 0
            analysis['total_cost'] = total_cost
            analysis['total_records'] = len(self.billing_data)
            
            # Service-wise breakdown
            if 'Service' in self.billing_data.columns:
                service_costs = self.billing_data.groupby('Service')['Cost'].agg(['sum', 'count']).round(2)
                analysis['service_breakdown'] = service_costs.to_dict('index')
                analysis['top_services'] = service_costs.sort_values('sum', ascending=False).head(10)
            
            # Account-wise analysis
            if 'Account' in self.billing_data.columns:
                account_costs = self.billing_data.groupby('Account')['Cost'].sum().round(2)
                analysis['account_breakdown'] = account_costs.to_dict()
            
            # Region-wise analysis
            if 'Region' in self.billing_data.columns:
                region_costs = self.billing_data.groupby('Region')['Cost'].sum().round(2)
                analysis['region_breakdown'] = region_costs.to_dict()
            
            # AWS-specific insights
            analysis['aws_insights'] = self._get_aws_specific_insights()
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing AWS billing: {str(e)}")
            return {"error": str(e)}

    def _get_aws_specific_insights(self) -> Dict:
        """Generate AWS-specific cost insights."""
        insights = {}
        
        try:
            if self.billing_data is None:
                return insights
            
            # EC2 analysis
            ec2_data = self.billing_data[self.billing_data['Service'].str.contains('EC2', case=False, na=False)]
            if not ec2_data.empty:
                insights['ec2'] = {
                    'total_cost': ec2_data['Cost'].sum(),
                    'instance_count': len(ec2_data),
                    'potential_savings': ec2_data['Cost'].sum() * 0.30  # Estimated 30% savings with RIs
                }
            
            # S3 analysis
            s3_data = self.billing_data[self.billing_data['Service'].str.contains('S3', case=False, na=False)]
            if not s3_data.empty:
                insights['s3'] = {
                    'total_cost': s3_data['Cost'].sum(),
                    'storage_optimization': s3_data['Cost'].sum() * 0.40  # Estimated 40% savings with lifecycle
                }
            
            # RDS analysis
            rds_data = self.billing_data[self.billing_data['Service'].str.contains('RDS', case=False, na=False)]
            if not rds_data.empty:
                insights['rds'] = {
                    'total_cost': rds_data['Cost'].sum(),
                    'reserved_savings': rds_data['Cost'].sum() * 0.35  # Estimated 35% savings with RIs
                }
            
            # Lambda analysis
            lambda_data = self.billing_data[self.billing_data['Service'].str.contains('Lambda', case=False, na=False)]
            if not lambda_data.empty:
                insights['lambda'] = {
                    'total_cost': lambda_data['Cost'].sum(),
                    'optimization_potential': lambda_data['Cost'].sum() * 0.20  # 20% memory optimization
                }
            
        except Exception as e:
            logger.error(f"Error generating AWS insights: {str(e)}")
        
        return insights

    def get_aws_recommendations(self, service_name: str, cost: float, usage_pattern: str = "Standard") -> str:
        """Get AWS-specific cost optimization recommendations."""
        try:
            chain = self.recommendation_prompt | self.llm | StrOutputParser()
            
            recommendations = chain.invoke({
                "service_name": service_name,
                "cost": cost,
                "usage_pattern": usage_pattern
            })
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting AWS recommendations: {str(e)}")
            return f"Error generating recommendations: {str(e)}"

    def analyze_reserved_instance_opportunities(self) -> Dict:
        """Analyze Reserved Instance opportunities for EC2 and RDS."""
        opportunities = {}
        
        try:
            if self.billing_data is None:
                return opportunities
            
            # EC2 Reserved Instance opportunities
            ec2_data = self.billing_data[self.billing_data['Service'].str.contains('EC2', case=False, na=False)]
            if not ec2_data.empty:
                total_ec2_cost = ec2_data['Cost'].sum()
                opportunities['ec2_reserved_instances'] = {
                    'current_monthly_cost': total_ec2_cost,
                    'estimated_ri_cost': total_ec2_cost * 0.70,  # 30% savings
                    'potential_monthly_savings': total_ec2_cost * 0.30,
                    'annual_savings': total_ec2_cost * 0.30 * 12,
                    'recommendation': 'Consider 1-year or 3-year Reserved Instances for steady-state workloads'
                }
            
            # RDS Reserved Instance opportunities
            rds_data = self.billing_data[self.billing_data['Service'].str.contains('RDS', case=False, na=False)]
            if not rds_data.empty:
                total_rds_cost = rds_data['Cost'].sum()
                opportunities['rds_reserved_instances'] = {
                    'current_monthly_cost': total_rds_cost,
                    'estimated_ri_cost': total_rds_cost * 0.65,  # 35% savings
                    'potential_monthly_savings': total_rds_cost * 0.35,
                    'annual_savings': total_rds_cost * 0.35 * 12,
                    'recommendation': 'RDS Reserved Instances offer significant savings for production databases'
                }
            
        except Exception as e:
            logger.error(f"Error analyzing RI opportunities: {str(e)}")
        
        return opportunities

    def analyze_storage_optimization(self) -> Dict:
        """Analyze S3 storage optimization opportunities."""
        storage_analysis = {}
        
        try:
            if self.billing_data is None:
                return storage_analysis
            
            # S3 storage analysis
            s3_data = self.billing_data[self.billing_data['Service'].str.contains('S3', case=False, na=False)]
            if not s3_data.empty:
                total_s3_cost = s3_data['Cost'].sum()
                
                storage_analysis['s3_optimization'] = {
                    'current_monthly_cost': total_s3_cost,
                    'intelligent_tiering_savings': total_s3_cost * 0.30,
                    'lifecycle_policy_savings': total_s3_cost * 0.40,
                    'glacier_migration_savings': total_s3_cost * 0.60,
                    'recommendations': [
                        'Enable S3 Intelligent Tiering for automatic cost optimization',
                        'Implement lifecycle policies to move data to cheaper storage classes',
                        'Consider Glacier or Deep Archive for long-term retention',
                        'Use S3 Storage Class Analysis to identify optimization opportunities'
                    ]
                }
            
            # EBS optimization
            ebs_data = self.billing_data[self.billing_data['Service'].str.contains('EBS', case=False, na=False)]
            if not ebs_data.empty:
                total_ebs_cost = ebs_data['Cost'].sum()
                storage_analysis['ebs_optimization'] = {
                    'current_monthly_cost': total_ebs_cost,
                    'gp3_migration_savings': total_ebs_cost * 0.20,
                    'recommendations': [
                        'Migrate gp2 volumes to gp3 for 20% cost savings',
                        'Right-size EBS volumes based on actual usage',
                        'Delete unattached EBS volumes'
                    ]
                }
        
        except Exception as e:
            logger.error(f"Error analyzing storage optimization: {str(e)}")
        
        return storage_analysis

    def get_comprehensive_aws_analysis(self, query: str) -> str:
        """Get comprehensive AWS billing analysis based on user query."""
        try:
            if self.billing_data is None:
                return "No AWS billing data loaded. Please load billing data first."
            
            # Generate billing summary
            billing_summary = f"""
            AWS Billing Summary:
            - Total Cost: ${self.billing_data['Cost'].sum():.2f}
            - Number of Services: {len(self.billing_data['Service'].unique()) if 'Service' in self.billing_data.columns else 'N/A'}
            - Top Services by Cost: {self.billing_data.groupby('Service')['Cost'].sum().sort_values(ascending=False).head(5).to_dict() if 'Service' in self.billing_data.columns else 'N/A'}
            
            User Query: {query}
            """
            
            # Use LLM for analysis
            chain = self.analysis_prompt | self.llm | StrOutputParser()
            analysis = chain.invoke({"billing_summary": billing_summary})
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error in comprehensive AWS analysis: {str(e)}")
            return f"Error performing AWS analysis: {str(e)}"
    
    def analyze_aws_costs_with_data(self, query: str, aws_data: pd.DataFrame) -> str:
        """Analyze AWS costs with actual billing data to answer specific questions"""
        try:
            # Analyze the AWS billing data to provide context
            total_cost = aws_data['Cost'].sum() if 'Cost' in aws_data.columns else 0
            
            # Get top services by cost
            top_services_text = "Service breakdown not available"
            if 'ServiceName' in aws_data.columns and 'Cost' in aws_data.columns:
                top_services = aws_data.groupby('ServiceName')['Cost'].sum().sort_values(ascending=False).head(5)
                top_services_text = "\n".join([f"- {service}: ${cost:,.2f}" for service, cost in top_services.items()])
            elif 'Service' in aws_data.columns and 'Cost' in aws_data.columns:
                top_services = aws_data.groupby('Service')['Cost'].sum().sort_values(ascending=False).head(5)
                top_services_text = "\n".join([f"- {service}: ${cost:,.2f}" for service, cost in top_services.items()])
            
            # Get date range
            date_range = "Date range not available"
            date_columns = ['UsageStartDate', 'Date', 'usage_start_date']
            for col in date_columns:
                if col in aws_data.columns:
                    try:
                        aws_data[col] = pd.to_datetime(aws_data[col])
                        min_date = aws_data[col].min().strftime('%Y-%m-%d')
                        max_date = aws_data[col].max().strftime('%Y-%m-%d')
                        date_range = f"{min_date} to {max_date}"
                        break
                    except:
                        continue
            
            # Create AWS-specific analysis prompt
            aws_query_prompt = ChatPromptTemplate.from_messages([
                ("system", """You are an AWS billing analysis expert. Answer the user's question based on the provided AWS billing data.
                
                Focus on AWS-specific services, pricing models, and cost optimization opportunities:
                - EC2 instances (Reserved Instances, Spot pricing, right-sizing)
                - S3 storage classes and lifecycle policies
                - RDS optimization (Reserved Instances, Aurora Serverless)
                - Lambda optimization and pricing models
                - EKS/Fargate vs EC2 cost analysis
                - AWS Savings Plans and Reserved Instance recommendations
                - Auto Scaling and rightsizing opportunities
                """),
                ("user", """USER QUESTION: {query}

AWS BILLING DATA ANALYSIS:
- Total AWS Cost: ${total_cost:,.2f}
- Date Range: {date_range}
- Data Points: {num_records} billing records

TOP AWS SERVICES BY COST:
{top_services}

INSTRUCTIONS:
1. Answer the specific question asked by the user
2. Use the actual AWS billing data provided above
3. Focus on AWS-specific services and optimization recommendations
4. Provide actionable insights for AWS cost optimization
5. Include specific AWS tools and features (Cost Explorer, Budgets, etc.)
6. If the data doesn't directly answer the question, explain what can be determined from the available AWS data

Response:""")
            ])
            
            chain = aws_query_prompt | self.llm | StrOutputParser()
            response = chain.invoke({
                "query": query,
                "total_cost": total_cost,
                "date_range": date_range,
                "num_records": len(aws_data),
                "top_services": top_services_text
            })
            
            return response
            
        except Exception as e:
            logger.error(f"Error analyzing AWS costs with data: {str(e)}")
            return f"I encountered an error analyzing your AWS billing data: {str(e)}. Please ensure your AWS billing data is properly formatted."