from typing import List, Dict, Any, Optional
from langchain_google_vertexai import ChatVertexAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain_community.vectorstores import FAISS
import streamlit as st
import os

class FinOpsRAGAgent:
    def __init__(self, vectorstore: Optional[FAISS] = None):
        project = os.getenv("GOOGLE_CLOUD_PROJECT")
        region = os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
        
        if not project:
            st.error("🔥 GOOGLE_CLOUD_PROJECT environment variable not set!")
            st.info("💡 Please set your Google Cloud Project ID in the .env file")
        
        self.llm = ChatVertexAI(
            model_name="gemini-2.5-flash",
            project=project,
            location=region,
            temperature=0.1,
            max_output_tokens=4096
        )
        self.vectorstore = vectorstore
        self.qa_chain = None
        self._setup_qa_chain()
    
    def _setup_qa_chain(self):
        """Setup the QA chain with FinOps-specific prompt"""
        finops_prompt = PromptTemplate(
            template="""You are a FinOps (Financial Operations) expert. Use the following context to answer questions about cloud financial management, cost optimization, and FinOps best practices.

Context: {context}

Question: {question}

Please provide a comprehensive answer that includes:
1. Direct answer to the question
2. Relevant FinOps concepts and terminology
3. Best practices and recommendations where applicable
4. Real-world implementation tips

If you don't know the answer based on the context, say so and provide general FinOps guidance.

Answer:""",
            input_variables=["context", "question"]
        )
        
        if self.vectorstore:
            self.qa_chain = RetrievalQA.from_chain_type(
                llm=self.llm,
                chain_type="stuff",
                retriever=self.vectorstore.as_retriever(search_kwargs={"k": 5}),
                chain_type_kwargs={"prompt": finops_prompt},
                return_source_documents=True
            )
        else:
            # Fallback to direct LLM without RAG
            simple_prompt = PromptTemplate(
                template="""You are a FinOps (Financial Operations) expert. Answer the following question about cloud financial management, cost optimization, and FinOps best practices.

Question: {question}

Please provide a comprehensive answer that includes:
1. Direct answer to the question
2. Relevant FinOps concepts and terminology
3. Best practices and recommendations where applicable
4. Real-world implementation tips

Answer:""",
                input_variables=["question"]
            )
            self.qa_chain = simple_prompt | self.llm
    
    def answer_question(self, question: str) -> Dict[str, Any]:
        """Answer a FinOps-related question"""
        try:
            if self.vectorstore:
                result = self.qa_chain.invoke({"query": question})
                return {
                    "answer": result["result"],
                    "source_documents": result.get("source_documents", []),
                    "sources": [doc.metadata.get("source", "Unknown") for doc in result.get("source_documents", [])]
                }
            else:
                result = self.qa_chain.invoke({"question": question})
                # Handle different response types
                answer = result.content if hasattr(result, 'content') else str(result)
                return {
                    "answer": answer,
                    "source_documents": [],
                    "sources": []
                }
        except Exception as e:
            st.error(f"Error answering question: {str(e)}")
            return {
                "answer": "I apologize, but I encountered an error while processing your question. Please try again.",
                "source_documents": [],
                "sources": []
            }
    
    def get_finops_concepts(self) -> List[str]:
        """Return common FinOps concepts for suggestions"""
        return [
            "What is FinOps?",
            "Cloud cost optimization strategies",
            "FinOps operating model and phases",
            "Cost allocation and showback/chargeback",
            "Reserved instances vs on-demand pricing",
            "Cloud cost monitoring and alerting",
            "FinOps team roles and responsibilities",
            "Cost anomaly detection",
            "Multi-cloud cost management",
            "FinOps KPIs and metrics",
            "Tagging strategies for cost management",
            "Cloud spend forecasting",
            "Cost governance and policies",
            "FinOps automation tools",
            "Unit economics in cloud computing"
        ]
    
    def generate_finops_explanation(self, topic: str) -> str:
        """Generate an explanation for a specific FinOps topic"""
        question = f"Please explain {topic} in the context of FinOps and cloud financial management."
        result = self.answer_question(question)
        return result["answer"]
    
    def get_best_practices(self, area: str) -> Dict[str, Any]:
        """Get best practices for a specific FinOps area"""
        question = f"What are the best practices for {area} in FinOps?"
        return self.answer_question(question)
    
    def analyze_cost_scenario(self, scenario: str) -> Dict[str, Any]:
        """Analyze a specific cost scenario and provide recommendations"""
        question = f"Given this cloud cost scenario: {scenario}. What FinOps recommendations would you provide?"
        return self.answer_question(question)