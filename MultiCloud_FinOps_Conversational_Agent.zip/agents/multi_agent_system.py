from typing import Dict, Any, List, Optional, Literal
from langgraph.graph import StateGraph, END
from langchain_google_vertexai import ChatVertexAI
from langchain.prompts import PromptTemplate
# from langchain.chains import LLMChain  # Using new format
from agents.finops_rag_agent import FinOpsRAGAgent
from agents.gcp_billing_agent import GCPBillingAgent
from agents.aws_finops_agent import AWSFinOpsAgent
from agents.azure_finops_agent import AzureFinOpsAgent
import streamlit as st
import os

# Define the state structure for the multi-agent system
class FinOpsState:
    def __init__(self):
        self.user_query: str = ""
        self.query_type: str = ""  # "finops_question", "gcp_billing", "aws_billing", "azure_billing", "multi_cloud"
        self.finops_response: Optional[Dict[str, Any]] = None
        self.gcp_response: Optional[Dict[str, Any]] = None
        self.aws_response: Optional[Dict[str, Any]] = None
        self.azure_response: Optional[Dict[str, Any]] = None
        self.final_response: str = ""
        self.cloud_platform: str = ""  # "gcp", "aws", "azure", "multi"
        self.billing_data: Optional[Dict[str, Any]] = None
        self.sources: List[str] = []

class MultiAgentFinOpsSystem:
    def __init__(self, finops_agent: FinOpsRAGAgent, gcp_agent: GCPBillingAgent, 
                 aws_agent: AWSFinOpsAgent = None, azure_agent: AzureFinOpsAgent = None):
        self.finops_agent = finops_agent
        self.gcp_agent = gcp_agent
        self.aws_agent = aws_agent
        self.azure_agent = azure_agent
        
        project = os.getenv("GOOGLE_CLOUD_PROJECT")
        region = os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
        
        self.llm = ChatVertexAI(
            model_name="gemini-2.5-flash",
            project=project,
            location=region,
            temperature=0.1,
            max_output_tokens=4096
        )
        self.graph = None
        self._build_graph()
    
    def _build_graph(self):
        """Build the LangGraph workflow"""
        workflow = StateGraph(dict)
        
        # Add nodes
        workflow.add_node("query_router", self._route_query)
        workflow.add_node("finops_agent", self._finops_agent_node)
        workflow.add_node("gcp_agent", self._gcp_agent_node)
        workflow.add_node("aws_agent", self._aws_agent_node)
        workflow.add_node("azure_agent", self._azure_agent_node)
        workflow.add_node("response_synthesizer", self._synthesize_response)
        
        # Add edges
        workflow.set_entry_point("query_router")
        
        # Conditional routing based on query type and cloud platform
        workflow.add_conditional_edges(
            "query_router",
            self._decide_next_node,
            {
                "finops_only": "finops_agent",
                "gcp_billing": "gcp_agent",
                "aws_billing": "aws_agent",
                "azure_billing": "azure_agent",
                "multi_cloud": "finops_agent"  # Start with finops for multi-cloud queries
            }
        )
        
        # From finops agent - can route to cloud-specific agents
        workflow.add_conditional_edges(
            "finops_agent",
            self._after_finops_node,
            {
                "gcp_needed": "gcp_agent",
                "aws_needed": "aws_agent",
                "azure_needed": "azure_agent",
                "synthesize": "response_synthesizer"
            }
        )
        
        # From cloud agents to synthesizer
        workflow.add_edge("gcp_agent", "response_synthesizer")
        workflow.add_edge("aws_agent", "response_synthesizer")
        workflow.add_edge("azure_agent", "response_synthesizer")
        
        # End at synthesizer
        workflow.add_edge("response_synthesizer", END)
        
        self.graph = workflow.compile()
    
    def _route_query(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Enhanced query routing based on cloud-specific keywords and billing data"""
        query = state.get("user_query", "").lower()
        
        # Enhanced cloud detection with comprehensive keywords
        gcp_keywords = [
            'gcp', 'google cloud', 'compute engine', 'cloud storage', 'bigquery', 'app engine',
            'cloud sql', 'kubernetes engine', 'gke', 'cloud functions', 'firebase', 'pub/sub',
            'cloud run', 'dataflow', 'dataproc', 'cloud spanner', 'cloud bigtable', 'vertex ai',
            'cloud cdn', 'cloud armor', 'cloud nat', 'cloud vpn', 'cloud interconnect'
        ]
        
        aws_keywords = [
            'aws', 'amazon web services', 'ec2', 's3', 'rds', 'lambda', 'cloudfront',
            'elb', 'elastic load balancer', 'route 53', 'cloudwatch', 'iam', 'vpc',
            'eks', 'ecs', 'fargate', 'dynamodb', 'redshift', 'sagemaker', 'elastic beanstalk',
            'cloudformation', 'sns', 'sqs', 'api gateway', 'amplify', 'cognito'
        ]
        
        azure_keywords = [
            'azure', 'microsoft azure', 'virtual machines', 'blob storage', 'sql database',
            'app service', 'functions', 'aks', 'kubernetes service', 'cosmos db',
            'service bus', 'event hubs', 'logic apps', 'azure active directory', 'ad',
            'application gateway', 'front door', 'traffic manager', 'devops', 'resource manager'
        ]
        
        # Check for cloud-specific mentions
        gcp_mentioned = any(keyword in query for keyword in gcp_keywords)
        aws_mentioned = any(keyword in query for keyword in aws_keywords)
        azure_mentioned = any(keyword in query for keyword in azure_keywords)
        
        # Count how many clouds are mentioned
        clouds_mentioned = sum([gcp_mentioned, aws_mentioned, azure_mentioned])
        
        # Determine routing based on cloud-specific detection
        if clouds_mentioned == 1:
            # Single cloud mentioned - route to specific agent with their billing data
            if gcp_mentioned:
                query_type = "gcp_billing"
                cloud_platform = "gcp"
            elif aws_mentioned:
                query_type = "aws_billing"
                cloud_platform = "aws"
            elif azure_mentioned:
                query_type = "azure_billing"
                cloud_platform = "azure"
        elif clouds_mentioned > 1:
            # Multiple clouds mentioned - use multi-cloud approach
            query_type = "multi_cloud"
            cloud_platform = "multi"
        else:
            # No specific cloud mentioned - check for general FinOps or cost-related terms
            cost_keywords = [
                'cost', 'billing', 'spend', 'budget', 'optimize', 'save', 'expensive',
                'usage', 'recommendation', 'forecast', 'trend', 'anomaly', 'waste',
                'price', 'charges', 'invoice', 'payment', 'total', 'breakdown'
            ]
            
            is_cost_query = any(keyword in query for keyword in cost_keywords)
            
            if is_cost_query:
                # Cost-related question without cloud specification - default to multi-cloud
                query_type = "multi_cloud"
                cloud_platform = "multi"
            else:
                # General FinOps question - route to FinOps RAG agent for best practices
                query_type = "finops_only"
                cloud_platform = "general"
        
        # Store routing decisions in state
        state["query_type"] = query_type
        state["cloud_platform"] = cloud_platform
        
        # Debug information for development
        if st.session_state.get('debug_mode', False):
            st.sidebar.write(f"🔍 Query routing: {cloud_platform} ({query_type})")
            if gcp_mentioned or aws_mentioned or azure_mentioned:
                detected_clouds = []
                if gcp_mentioned: detected_clouds.append("GCP")
                if aws_mentioned: detected_clouds.append("AWS") 
                if azure_mentioned: detected_clouds.append("Azure")
                st.sidebar.write(f"📡 Detected clouds: {', '.join(detected_clouds)}")
        
        return state
    
    def _decide_next_node(self, state: Dict[str, Any]) -> str:
        """Decide which node to visit next after routing"""
        return state.get("query_type", "finops_only")
    
    def _after_finops_node(self, state: Dict[str, Any]) -> str:
        """Decide what to do after finops agent processes the query"""
        cloud_platform = state.get("cloud_platform", "gcp")
        has_billing_data = state.get("billing_data") is not None
        query = state.get("user_query", "").lower()
        
        if has_billing_data and ("analyze" in query or "cost" in query):
            if cloud_platform == "aws":
                return "aws_needed"
            elif cloud_platform == "azure":
                return "azure_needed"
            else:
                return "gcp_needed"
        else:
            return "synthesize"
    
    def _finops_agent_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Enhanced FinOps RAG agent processing node with multi-cloud focus"""
        try:
            from utils.enhanced_query_processor import EnhancedQueryProcessor, create_enhanced_prompt
            
            query = state.get("user_query", "")
            
            # Use enhanced query processing for better multi-cloud responses
            processor = EnhancedQueryProcessor()
            analysis = processor.analyze_query(query)
            
            # Get available multi-cloud cost data for context
            available_data = None
            if hasattr(st.session_state, 'multi_cloud_costs') and st.session_state.multi_cloud_costs:
                available_data = st.session_state.multi_cloud_costs
            
            # Create enhanced prompt
            enhanced_prompt = create_enhanced_prompt(query, analysis, available_data)
            
            # Use the enhanced prompt with the FinOps agent
            if self.finops_agent and hasattr(self.finops_agent, 'llm'):
                # Direct LLM call with enhanced prompt for better responses
                enhanced_response = self.finops_agent.llm.invoke(enhanced_prompt)
                response = {
                    "answer": enhanced_response.content,
                    "sources": [],
                    "enhanced": True,
                    "analysis": analysis
                }
            else:
                # Fallback to regular agent
                response = self.finops_agent.answer_question(query) if self.finops_agent else {
                    "answer": "FinOps agent not available",
                    "sources": []
                }
            
            state["finops_response"] = response
            if "sources" in response:
                state["sources"].extend(response.get("sources", []))
                
        except Exception as e:
            st.error(f"Error in FinOps agent: {str(e)}")
            state["finops_response"] = {
                "answer": "I apologize, but I encountered an error while processing your FinOps question. Please try rephrasing your question.",
                "sources": []
            }
        return state
    
    def _gcp_agent_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """GCP Billing agent processing node with query-specific analysis"""
        try:
            query = state.get("user_query", "")
            
            # Load GCP billing data from session state if available
            gcp_data = None
            if hasattr(st.session_state, 'gcp_data') and st.session_state.gcp_data is not None:
                gcp_data = st.session_state.gcp_data
            
            if gcp_data is not None and not gcp_data.empty:
                # Use the query-based analysis method for GCP-specific questions
                response = self.gcp_agent.query_billing_data(query, gcp_data)
                state["gcp_response"] = {"analysis": response}
            else:
                # Fallback to general GCP guidance
                response = self.gcp_agent.get_gcp_finops_guidance(query)
                state["gcp_response"] = {"analysis": response}
                
        except Exception as e:
            st.error(f"Error in GCP agent: {str(e)}")
            state["gcp_response"] = {
                "analysis": f"I encountered an error while processing your GCP question: {str(e)}. Please try rephrasing your question."
            }
        return state
    
    def _aws_agent_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """AWS FinOps agent processing node with billing data integration"""
        try:
            query = state.get("user_query", "")
            
            if self.aws_agent:
                # Load AWS billing data from session state if available
                aws_data = None
                if hasattr(st.session_state, 'aws_data') and st.session_state.aws_data is not None:
                    aws_data = st.session_state.aws_data
                
                if aws_data is not None and not aws_data.empty:
                    # Use billing data for analysis if available
                    response = self.aws_agent.analyze_aws_costs_with_data(query, aws_data)
                else:
                    # Fallback to general AWS guidance
                    response = self.aws_agent.get_comprehensive_aws_analysis(query)
                
                state["aws_response"] = {"analysis": response}
            else:
                state["aws_response"] = {
                    "analysis": "AWS FinOps agent not available."
                }
        except Exception as e:
            st.error(f"Error in AWS agent: {str(e)}")
            state["aws_response"] = {
                "analysis": "I encountered an error while processing AWS analysis."
            }
        return state
    
    def _azure_agent_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Azure FinOps agent processing node with billing data integration"""
        try:
            query = state.get("user_query", "")
            
            if self.azure_agent:
                # Load Azure billing data from session state if available
                azure_data = None
                if hasattr(st.session_state, 'azure_data') and st.session_state.azure_data is not None:
                    azure_data = st.session_state.azure_data
                
                if azure_data is not None and not azure_data.empty:
                    # Use billing data for analysis if available
                    response = self.azure_agent.analyze_azure_costs_with_data(query, azure_data)
                else:
                    # Fallback to general Azure guidance
                    response = self.azure_agent.get_comprehensive_azure_analysis(query)
                
                state["azure_response"] = {"analysis": response}
            else:
                state["azure_response"] = {
                    "analysis": "Azure FinOps agent not available."
                }
        except Exception as e:
            st.error(f"Error in Azure agent: {str(e)}")
            state["azure_response"] = {
                "analysis": "I encountered an error while processing Azure analysis."
            }
        return state
    
    def _synthesize_response(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Synthesize responses from agents based on routing decision"""
        try:
            finops_response = state.get("finops_response")
            gcp_response = state.get("gcp_response")
            aws_response = state.get("aws_response") 
            azure_response = state.get("azure_response")
            user_query = state.get("user_query", "")
            query_type = state.get("query_type", "")
            cloud_platform = state.get("cloud_platform", "multi")
            
            # Handle cloud-specific responses directly
            if query_type == "gcp_billing" and gcp_response:
                state["final_response"] = gcp_response.get('analysis', 'No GCP analysis available.')
                return state
            elif query_type == "aws_billing" and aws_response:
                state["final_response"] = aws_response.get('analysis', 'No AWS analysis available.')
                return state
            elif query_type == "azure_billing" and azure_response:
                state["final_response"] = azure_response.get('analysis', 'No Azure analysis available.')
                return state
            elif query_type == "finops_only" and finops_response:
                state["final_response"] = finops_response.get('answer', 'No FinOps analysis available.')
                return state
            
            # For multi-cloud responses, synthesize available responses
            responses = []
            if finops_response:
                responses.append(f"FinOps Expert: {finops_response.get('answer', '')}")
            if gcp_response and query_type == "multi_cloud":
                responses.append(f"GCP Analysis: {gcp_response.get('analysis', '')}")
            if aws_response and query_type == "multi_cloud":
                responses.append(f"AWS Analysis: {aws_response.get('analysis', '')}")
            if azure_response and query_type == "multi_cloud":
                responses.append(f"Azure Analysis: {azure_response.get('analysis', '')}")
            
            # Create synthesis prompt for multi-cloud responses
            synthesis_prompt = PromptTemplate(
                template="""You are a senior FinOps expert providing focused, actionable guidance.

USER QUERY: {user_query}

ROUTING: This was identified as a {query_type} query for {cloud_platform} platform(s).

AVAILABLE RESPONSES:
{agent_responses}

MULTI-CLOUD COST CONTEXT:
{cost_context}

SYNTHESIS GUIDELINES:
1. FOCUS: Answer the specific question asked - be direct and concise
2. CLOUD CONTEXT: Based on routing, provide {cloud_platform} specific guidance
3. PRACTICAL: Include actionable recommendations with real-world examples
4. STRUCTURE: Use clear headings and bullet points for readability
5. DATA-DRIVEN: Base recommendations on actual cost data when available

RESPONSE FORMAT:
- Start with a direct answer to the user's question
- Provide specific, actionable recommendations
- Keep response concise but comprehensive

Synthesized FinOps Response:""",
                input_variables=["user_query", "agent_responses", "cost_context", "query_type", "cloud_platform"]
            )
            
            synthesis_chain = synthesis_prompt | self.llm
            
            agent_responses_text = "\n\n".join(responses) if responses else "No specialized analysis performed."
            
            # Add multi-cloud cost context if available
            cost_context = "No current billing data available."
            if hasattr(st.session_state, 'multi_cloud_costs') and st.session_state.multi_cloud_costs:
                costs = st.session_state.multi_cloud_costs
                total = costs['total_cost']
                breakdown = costs['cost_breakdown']
                cost_context = f"Current multi-cloud spending: ${total:,.2f} across {len(breakdown)} providers: "
                cost_context += ", ".join([f"{provider}: ${cost:,.2f}" for provider, cost in breakdown.items() if cost > 0])
            
            synthesis_response = synthesis_chain.invoke({
                "user_query": user_query,
                "agent_responses": agent_responses_text,
                "cost_context": cost_context,
                "query_type": query_type,
                "cloud_platform": cloud_platform
            })
            synthesized = synthesis_response.content if hasattr(synthesis_response, 'content') else str(synthesis_response)
            
            state["final_response"] = synthesized
            
        except Exception as e:
            st.error(f"Error synthesizing response: {str(e)}")
            # Fallback to individual responses
            fallback_responses = []
            if state.get("finops_response"):
                fallback_responses.append(state["finops_response"]["answer"])
            if state.get("gcp_response"):
                fallback_responses.append(state["gcp_response"]["analysis"])
            if state.get("aws_response"):
                fallback_responses.append(state["aws_response"]["analysis"])
            if state.get("azure_response"):
                fallback_responses.append(state["azure_response"]["analysis"])
            
            state["final_response"] = "\n\n".join(fallback_responses) if fallback_responses else "I apologize, but I couldn't process your request."
        
        return state
    
    def process_query(self, user_query: str, billing_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process a user query through the multi-agent system"""
        # Initialize state
        initial_state = {
            "user_query": user_query,
            "billing_data": billing_data,
            "sources": [],
            "query_type": "",
            "cloud_platform": "",
            "finops_response": None,
            "gcp_response": None,
            "aws_response": None,
            "azure_response": None,
            "final_response": ""
        }
        
        # Run the graph
        try:
            result = self.graph.invoke(initial_state)
            return {
                "response": result["final_response"],
                "finops_details": result.get("finops_response"),
                "gcp_details": result.get("gcp_response"),
                "aws_details": result.get("aws_response"),
                "azure_details": result.get("azure_response"),
                "sources": result.get("sources", []),
                "query_type": result.get("query_type", "")
            }
        except Exception as e:
            st.error(f"Error in multi-agent system: {str(e)}")
            return {
                "response": "I apologize, but I encountered an error while processing your request. Please try again.",
                "finops_details": None,
                "billing_details": None,
                "sources": [],
                "query_type": ""
            }
    
    def get_capabilities(self) -> List[str]:
        """Return list of system capabilities"""
        return [
            "Answer FinOps questions and explain concepts",
            "Analyze GCP/Azure/AWS billing data and provide insights",
            "Generate cost optimization recommendations",
            "Provide best practices for cloud financial management",
            "Forecast future costs based on historical data",
        ]