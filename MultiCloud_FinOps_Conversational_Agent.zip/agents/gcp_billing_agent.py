"""
GCP Billing Agent for analyzing Google Cloud Platform billing data and providing cost optimization recommendations.
"""

from typing import Dict, List, Any, Optional
from langchain_google_vertexai import ChatVertexAI
from langchain.prompts import PromptTemplate

import pandas as pd
import json
import streamlit as st
import os

class GCPBillingAgent:
    def __init__(self):
        project = os.getenv("GOOGLE_CLOUD_PROJECT")
        region = os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
        
        self.llm = ChatVertexAI(
            model_name="gemini-2.5-flash",
            project=project,
            location=region,
            temperature=0.1,
            max_output_tokens=4096
        )
        self.analysis_chain = None
        self._setup_analysis_chain()
    
    def _setup_analysis_chain(self):
        """Setup the analysis chain for GCP billing insights"""
        analysis_prompt = PromptTemplate(
            template="""You are a Google Cloud Platform (GCP) billing analysis expert specializing in FinOps. 

Analyze the following GCP billing data and provide insights:

Billing Summary:
- Total Cost: ${total_cost:,.2f}
- Date Range: {date_range}
- Number of Services: {num_services}
- Number of Projects: {num_projects}

Top Services by Cost:
{top_services}

Service Breakdown:
{service_breakdown}

Project Breakdown:
{project_breakdown}

Cost Trends:
{cost_trends}

Based on this data, provide:
1. **Key Insights**: 3-5 most important findings about the spending patterns
2. **Cost Optimization Opportunities**: Specific recommendations for reducing costs
3. **Resource Allocation Analysis**: Comments on how resources are distributed
4. **Risk Assessment**: Potential cost risks or anomalies to watch
5. **Action Items**: Concrete next steps for FinOps implementation

Format your response in clear sections with actionable insights.

Analysis:""",
            input_variables=[
                "total_cost", "date_range", "num_services", "num_projects",
                "top_services", "service_breakdown", "project_breakdown", "cost_trends"
            ]
        )
        
        self.analysis_chain = analysis_prompt | self.llm
    
    def analyze_billing_data(self, billing_insights: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze GCP billing data and provide detailed insights"""
        try:
            # Format data for analysis
            total_cost = billing_insights.get('total_cost', 0)
            
            # Format top services
            top_services = billing_insights.get('top_cost_services', [])
            top_services_text = "\n".join([
                f"- {item['service']}: ${item['cost']:,.2f}"
                for item in top_services[:10]
            ]) if top_services else "No service data available"
            
            # Format service breakdown
            service_breakdown = billing_insights.get('service_breakdown', {})
            service_text = "\n".join([
                f"- {service}: ${cost:,.2f}"
                for service, cost in sorted(service_breakdown.items(), key=lambda x: x[1], reverse=True)[:10]
            ]) if service_breakdown else "No service breakdown available"
            
            # Format project breakdown
            project_breakdown = billing_insights.get('project_breakdown', {})
            project_text = "\n".join([
                f"- {project}: ${cost:,.2f}"
                for project, cost in sorted(project_breakdown.items(), key=lambda x: x[1], reverse=True)[:10]
            ]) if project_breakdown else "No project breakdown available"
            
            # Format cost trends
            cost_trends = billing_insights.get('cost_trends', {})
            trends_text = f"Trend Direction: {cost_trends.get('trend_direction', 'Unknown')}" if cost_trends else "No trend data available"
            
            # Get summary stats if available
            raw_data = billing_insights.get('raw_data')
            date_range = "Unknown"
            if raw_data is not None and not raw_data.empty:
                date_columns = [col for col in raw_data.columns if 'date' in col.lower() or 'time' in col.lower()]
                if date_columns:
                    try:
                        dates = pd.to_datetime(raw_data[date_columns[0]], errors='coerce').dropna()
                        if not dates.empty:
                            date_range = f"{dates.min().strftime('%Y-%m-%d')} to {dates.max().strftime('%Y-%m-%d')}"
                    except:
                        pass
            
            # Run analysis
            analysis_response = self.analysis_chain.invoke({
                "total_cost": total_cost,
                "date_range": date_range,
                "num_services": len(service_breakdown),
                "num_projects": len(project_breakdown),
                "top_services": top_services_text,
                "service_breakdown": service_text,
                "project_breakdown": project_text,
                "cost_trends": trends_text
            })
            analysis_result = analysis_response.content if hasattr(analysis_response, 'content') else str(analysis_response)
            
            return {
                "analysis": analysis_result,
                "summary": {
                    "total_cost": total_cost,
                    "top_service": top_services[0] if top_services else None,
                    "cost_trend": cost_trends.get('trend_direction', 'unknown'),
                    "num_services": len(service_breakdown),
                    "num_projects": len(project_breakdown)
                },
                "recommendations": self._extract_recommendations(billing_insights)
            }
            
        except Exception as e:
            st.error(f"Error analyzing billing data: {str(e)}")
            return {
                "analysis": "Unable to complete analysis due to an error.",
                "summary": {},
                "recommendations": []
            }
    
    def _extract_recommendations(self, insights: Dict[str, Any]) -> List[str]:
        """Extract specific recommendations based on the data"""
        recommendations = []
        
        total_cost = insights.get('total_cost', 0)
        service_breakdown = insights.get('service_breakdown', {})
        
        if total_cost > 10000:  # High spend threshold
            recommendations.append("🚨 High cloud spend detected - implement cost monitoring alerts")
        
        if service_breakdown:
            # Find service consuming most cost
            top_service = max(service_breakdown.items(), key=lambda x: x[1])
            service_name, service_cost = top_service
            percentage = (service_cost / total_cost * 100) if total_cost > 0 else 0
            
            if percentage > 60:
                recommendations.append(f"⚠️ {service_name} accounts for {percentage:.1f}% of costs - review for optimization opportunities")
            
            # Check for compute services
            compute_services = ['Compute Engine', 'Google Kubernetes Engine', 'Cloud Run', 'App Engine']
            for service in compute_services:
                if any(comp_service.lower() in service.lower() for comp_service in compute_services if service in service_breakdown):
                    recommendations.append("💡 Consider rightsizing compute resources and using committed use discounts")
                    break
        
        return recommendations
    
    def compare_periods(self, current_data: Dict[str, Any], previous_data: Dict[str, Any]) -> Dict[str, Any]:
        """Compare billing data between two periods"""
        current_cost = current_data.get('total_cost', 0)
        previous_cost = previous_data.get('total_cost', 0)
        
        if previous_cost > 0:
            cost_change = ((current_cost - previous_cost) / previous_cost) * 100
        else:
            cost_change = 0
        
        comparison_prompt = PromptTemplate(
            template="""Compare these two GCP billing periods:

Current Period:
- Total Cost: ${current_cost:,.2f}
- Top Service: {current_top_service}

Previous Period:
- Total Cost: ${previous_cost:,.2f}
- Top Service: {previous_top_service}

Cost Change: {cost_change:+.1f}%

Provide insights on:
1. Significant changes and their potential causes
2. Services with notable cost variations
3. Recommendations for managing the changes
4. Risk assessment for future periods

Analysis:""",
            input_variables=["current_cost", "current_top_service", "previous_cost", 
                           "previous_top_service", "cost_change"]
        )
        
        comparison_chain = comparison_prompt | self.llm
        
        current_top = current_data.get('top_cost_services', [{}])[0]
        previous_top = previous_data.get('top_cost_services', [{}])[0]
        
        comparison_response = comparison_chain.invoke({
            "current_cost": current_cost,
            "current_top_service": current_top.get('service', 'Unknown'),
            "previous_cost": previous_cost,
            "previous_top_service": previous_top.get('service', 'Unknown'),
            "cost_change": cost_change
        })
        result = comparison_response.content if hasattr(comparison_response, 'content') else str(comparison_response)
        
        return {
            "comparison_analysis": result,
            "cost_change_percentage": cost_change,
            "cost_difference": current_cost - previous_cost
        }
    
    def forecast_costs(self, historical_data: Dict[str, Any], months_ahead: int = 3) -> Dict[str, Any]:
        """Generate cost forecasts based on historical data"""
        forecast_prompt = PromptTemplate(
            template="""Based on the following GCP billing historical data, provide a cost forecast:

Historical Data:
- Current monthly average: ${avg_cost:,.2f}
- Cost trend: {trend}
- Top cost drivers: {top_services}

Generate a {months_ahead}-month forecast including:
1. Predicted monthly costs with reasoning
2. Factors that could influence costs (seasonality, growth, etc.)
3. Risk factors and potential cost spikes
4. Recommendations for cost predictability

Forecast Analysis:""",
            input_variables=["avg_cost", "trend", "top_services", "months_ahead"]
        )
        
        forecast_chain = forecast_prompt | self.llm
        
        avg_cost = historical_data.get('avg_daily_cost', 0) * 30  # Monthly estimate
        trend = historical_data.get('cost_trends', {}).get('trend_direction', 'stable')
        top_services = ", ".join([
            item['service'] for item in historical_data.get('top_cost_services', [])[:5]
        ])
        
        forecast_response = forecast_chain.invoke({
            "avg_cost": avg_cost,
            "trend": trend,
            "top_services": top_services or "No service data",
            "months_ahead": months_ahead
        })
        result = forecast_response.content if hasattr(forecast_response, 'content') else str(forecast_response)
        
        return {
            "forecast_analysis": result,
            "base_monthly_cost": avg_cost,
            "trend_direction": trend
        }
    
    def query_billing_data(self, query: str, gcp_data: pd.DataFrame) -> str:
        """Query GCP billing data with specific user questions"""
        try:
            # Analyze the billing data to provide context
            total_cost = gcp_data['cost'].sum() if 'cost' in gcp_data.columns else 0
            
            # Get top services by cost
            if 'service.description' in gcp_data.columns and 'cost' in gcp_data.columns:
                top_services = gcp_data.groupby('service.description')['cost'].sum().sort_values(ascending=False).head(5)
                top_services_text = "\n".join([f"- {service}: ${cost:,.2f}" for service, cost in top_services.items()])
            else:
                top_services_text = "Service breakdown not available"
            
            # Get usage patterns
            date_range = "Date range not available"
            if 'usage_start_time' in gcp_data.columns:
                try:
                    gcp_data['usage_start_time'] = pd.to_datetime(gcp_data['usage_start_time'])
                    min_date = gcp_data['usage_start_time'].min().strftime('%Y-%m-%d')
                    max_date = gcp_data['usage_start_time'].max().strftime('%Y-%m-%d')
                    date_range = f"{min_date} to {max_date}"
                except:
                    pass
            
            query_prompt = PromptTemplate(
                template="""You are a GCP billing analysis expert. Answer the user's question based on the provided GCP billing data.

USER QUESTION: {query}

GCP BILLING DATA ANALYSIS:
- Total GCP Cost: ${total_cost:,.2f}
- Date Range: {date_range}
- Data Points: {num_records} billing records

TOP GCP SERVICES BY COST:
{top_services}

INSTRUCTIONS:
1. Answer the specific question asked by the user
2. Use the actual GCP billing data provided above
3. Focus on GCP-specific services and recommendations
4. Provide actionable insights for GCP cost optimization
5. If the data doesn't directly answer the question, explain what can be determined from the available GCP data

Response:""",
                input_variables=["query", "total_cost", "date_range", "num_records", "top_services"]
            )
            
            chain = query_prompt | self.llm
            response = chain.invoke({
                "query": query,
                "total_cost": total_cost,
                "date_range": date_range,
                "num_records": len(gcp_data),
                "top_services": top_services_text
            })
            
            return response.content if hasattr(response, 'content') else str(response)
            
        except Exception as e:
            return f"I encountered an error analyzing your GCP billing data: {str(e)}. Please ensure your GCP billing data is properly formatted."
    
    def get_gcp_finops_guidance(self, query: str) -> str:
        """Provide general GCP FinOps guidance when billing data is not available"""
        guidance_prompt = PromptTemplate(
            template="""You are a GCP FinOps expert. Provide guidance for the following question about Google Cloud Platform cost management and optimization.

USER QUESTION: {query}

INSTRUCTIONS:
1. Focus specifically on Google Cloud Platform services and best practices
2. Provide actionable GCP cost optimization recommendations
3. Include specific GCP services, tools, and features that can help
4. Mention relevant GCP pricing models, committed use discounts, sustained use discounts
5. Reference GCP-specific cost management tools like Cloud Billing, Budget alerts, etc.
6. Keep recommendations practical and implementable

GCP FinOps Guidance:""",
            input_variables=["query"]
        )
        
        try:
            chain = guidance_prompt | self.llm
            response = chain.invoke({"query": query})
            return response.content if hasattr(response, 'content') else str(response)
        except Exception as e:
            return f"I encountered an error providing GCP guidance: {str(e)}. Please try rephrasing your question."