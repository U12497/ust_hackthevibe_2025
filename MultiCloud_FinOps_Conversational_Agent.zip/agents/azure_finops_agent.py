"""
Azure FinOps Agent for cost optimization and billing analysis specific to Azure services.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
from langchain_google_vertexai import ChatVertexAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AzureFinOpsAgent:
    """Azure-specific FinOps agent for cost analysis and optimization recommendations."""
    
    def __init__(self, project_id: str = "ews-cde-djfp1-dev-npe-6b86"):
        """Initialize the Azure FinOps agent with Vertex AI."""
        self.project_id = project_id
        self.llm = ChatVertexAI(
            model_name="gemini-2.5-flash",
            project=project_id,
            temperature=0.1
        )
        self.billing_data = None
        
        # Azure-specific cost optimization prompts
        self.analysis_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert Azure FinOps analyst with deep knowledge of Azure services, pricing models, and cost optimization strategies.
            
            Azure-Specific Expertise:
            - Virtual Machines: Reserved VM Instances, Spot VMs, B-series burstable VMs, Right-sizing
            - Azure Storage: Access tiers (Hot, Cool, Archive), Lifecycle management
            - Azure SQL Database: Serverless, Reserved Capacity, Elastic Pools
            - Azure Functions: Consumption vs Premium vs Dedicated plans
            - Azure Kubernetes Service: Cluster autoscaler, Virtual nodes, Spot node pools
            - Azure CDN: Pricing tiers, Regional optimization
            - Azure Cosmos DB: Serverless vs Provisioned, Autoscale
            - Azure App Service: Pricing tiers, Auto-scaling rules
            - Azure Cost Management: Cost analysis, Budgets, Recommendations
            - Azure Hybrid Benefit for Windows and SQL Server
            - Azure Reservations vs Pay-as-you-go
            - Azure Well-Architected Framework cost optimization
            
            Provide specific Azure recommendations with estimated savings percentages.
            """),
            ("user", "Analyze this Azure billing data and provide cost optimization recommendations:\n\n{billing_summary}")
        ])
        
        self.recommendation_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an Azure cost optimization expert. Provide detailed, actionable recommendations for Azure cost reduction.
            
            Focus on:
            1. Azure Reserved VM Instances analysis
            2. VM right-sizing opportunities (CPU, memory utilization)
            3. Azure Storage access tier optimization
            4. Azure SQL Database optimization (Serverless, Reserved Capacity)
            5. Azure Functions plan optimization
            6. Azure Hybrid Benefit opportunities
            7. Azure Spot VMs for non-critical workloads
            8. App Service plan right-sizing
            9. Unused or underutilized resources identification
            10. Multi-region vs Single-region cost considerations
            
            Include specific Azure service recommendations and estimated monthly savings.
            """),
            ("user", "Service: {service_name}\nCost: ${cost:.2f}\nUsage Pattern: {usage_pattern}\n\nProvide specific Azure optimization recommendations:")
        ])

    def load_billing_data(self, csv_path: str) -> bool:
        """Load Azure billing data from CSV file."""
        try:
            self.billing_data = pd.read_csv(csv_path)
            
            # Standardize Azure CSV columns
            column_mapping = {
                'Service Name': 'Service',
                'Pre-Tax Cost': 'Cost',
                'Usage Quantity': 'Usage',
                'Resource Name': 'Resource',
                'Subscription ID': 'Subscription',
                'Resource Group': 'ResourceGroup',
                'Location': 'Location',
                'Meter Category': 'MeterCategory'
            }
            
            for old_col, new_col in column_mapping.items():
                if old_col in self.billing_data.columns:
                    self.billing_data = self.billing_data.rename(columns={old_col: new_col})
            
            # Convert cost to numeric
            if 'Cost' in self.billing_data.columns:
                self.billing_data['Cost'] = pd.to_numeric(self.billing_data['Cost'], errors='coerce')
            
            logger.info(f"Successfully loaded Azure billing data with {len(self.billing_data)} records")
            return True
            
        except Exception as e:
            logger.error(f"Error loading Azure billing data: {str(e)}")
            return False

    def analyze_azure_billing(self) -> Dict:
        """Perform comprehensive Azure billing analysis."""
        if self.billing_data is None:
            return {"error": "No billing data loaded"}
        
        try:
            analysis = {}
            
            # Basic statistics
            total_cost = self.billing_data['Cost'].sum() if 'Cost' in self.billing_data.columns else 0
            analysis['total_cost'] = total_cost
            analysis['total_records'] = len(self.billing_data)
            
            # Service-wise breakdown
            if 'Service' in self.billing_data.columns:
                service_costs = self.billing_data.groupby('Service')['Cost'].agg(['sum', 'count']).round(2)
                analysis['service_breakdown'] = service_costs.to_dict('index')
                analysis['top_services'] = service_costs.sort_values('sum', ascending=False).head(10)
            
            # Subscription-wise analysis
            if 'Subscription' in self.billing_data.columns:
                subscription_costs = self.billing_data.groupby('Subscription')['Cost'].sum().round(2)
                analysis['subscription_breakdown'] = subscription_costs.to_dict()
            
            # Location-wise analysis
            if 'Location' in self.billing_data.columns:
                location_costs = self.billing_data.groupby('Location')['Cost'].sum().round(2)
                analysis['location_breakdown'] = location_costs.to_dict()
            
            # Resource Group analysis
            if 'ResourceGroup' in self.billing_data.columns:
                rg_costs = self.billing_data.groupby('ResourceGroup')['Cost'].sum().round(2)
                analysis['resource_group_breakdown'] = rg_costs.to_dict()
            
            # Azure-specific insights
            analysis['azure_insights'] = self._get_azure_specific_insights()
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing Azure billing: {str(e)}")
            return {"error": str(e)}

    def _get_azure_specific_insights(self) -> Dict:
        """Generate Azure-specific cost insights."""
        insights = {}
        
        try:
            if self.billing_data is None:
                return insights
            
            # Virtual Machines analysis
            vm_data = self.billing_data[self.billing_data['Service'].str.contains('Virtual Machines', case=False, na=False)]
            if not vm_data.empty:
                insights['virtual_machines'] = {
                    'total_cost': vm_data['Cost'].sum(),
                    'vm_count': len(vm_data),
                    'reserved_instance_savings': vm_data['Cost'].sum() * 0.40,  # Up to 40% savings with RIs
                    'spot_vm_savings': vm_data['Cost'].sum() * 0.80  # Up to 80% savings with Spot VMs
                }
            
            # Storage analysis
            storage_data = self.billing_data[self.billing_data['Service'].str.contains('Storage', case=False, na=False)]
            if not storage_data.empty:
                insights['storage'] = {
                    'total_cost': storage_data['Cost'].sum(),
                    'tier_optimization_savings': storage_data['Cost'].sum() * 0.50  # Up to 50% with Cool/Archive tiers
                }
            
            # SQL Database analysis
            sql_data = self.billing_data[self.billing_data['Service'].str.contains('SQL Database', case=False, na=False)]
            if not sql_data.empty:
                insights['sql_database'] = {
                    'total_cost': sql_data['Cost'].sum(),
                    'serverless_savings': sql_data['Cost'].sum() * 0.30,  # 30% savings with Serverless
                    'reserved_capacity_savings': sql_data['Cost'].sum() * 0.35  # 35% savings with Reserved Capacity
                }
            
            # App Service analysis
            app_service_data = self.billing_data[self.billing_data['Service'].str.contains('App Service', case=False, na=False)]
            if not app_service_data.empty:
                insights['app_service'] = {
                    'total_cost': app_service_data['Cost'].sum(),
                    'right_sizing_savings': app_service_data['Cost'].sum() * 0.25  # 25% savings with right-sizing
                }
            
        except Exception as e:
            logger.error(f"Error generating Azure insights: {str(e)}")
        
        return insights

    def get_azure_recommendations(self, service_name: str, cost: float, usage_pattern: str = "Standard") -> str:
        """Get Azure-specific cost optimization recommendations."""
        try:
            chain = self.recommendation_prompt | self.llm | StrOutputParser()
            
            recommendations = chain.invoke({
                "service_name": service_name,
                "cost": cost,
                "usage_pattern": usage_pattern
            })
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting Azure recommendations: {str(e)}")
            return f"Error generating recommendations: {str(e)}"

    def analyze_reserved_instance_opportunities(self) -> Dict:
        """Analyze Reserved Instance opportunities for Azure VMs and SQL."""
        opportunities = {}
        
        try:
            if self.billing_data is None:
                return opportunities
            
            # VM Reserved Instance opportunities
            vm_data = self.billing_data[self.billing_data['Service'].str.contains('Virtual Machines', case=False, na=False)]
            if not vm_data.empty:
                total_vm_cost = vm_data['Cost'].sum()
                opportunities['vm_reserved_instances'] = {
                    'current_monthly_cost': total_vm_cost,
                    'estimated_ri_cost': total_vm_cost * 0.60,  # Up to 40% savings
                    'potential_monthly_savings': total_vm_cost * 0.40,
                    'annual_savings': total_vm_cost * 0.40 * 12,
                    'recommendation': 'Consider 1-year or 3-year Azure Reserved VM Instances for steady workloads'
                }
            
            # SQL Database Reserved Capacity opportunities
            sql_data = self.billing_data[self.billing_data['Service'].str.contains('SQL Database', case=False, na=False)]
            if not sql_data.empty:
                total_sql_cost = sql_data['Cost'].sum()
                opportunities['sql_reserved_capacity'] = {
                    'current_monthly_cost': total_sql_cost,
                    'estimated_reserved_cost': total_sql_cost * 0.65,  # 35% savings
                    'potential_monthly_savings': total_sql_cost * 0.35,
                    'annual_savings': total_sql_cost * 0.35 * 12,
                    'recommendation': 'Azure SQL Database Reserved Capacity offers significant savings for production databases'
                }
            
        except Exception as e:
            logger.error(f"Error analyzing Azure RI opportunities: {str(e)}")
        
        return opportunities

    def analyze_azure_hybrid_benefit(self) -> Dict:
        """Analyze Azure Hybrid Benefit opportunities."""
        hybrid_benefit = {}
        
        try:
            if self.billing_data is None:
                return hybrid_benefit
            
            # Windows VM Hybrid Benefit
            windows_vm_data = self.billing_data[
                (self.billing_data['Service'].str.contains('Virtual Machines', case=False, na=False)) &
                (self.billing_data['Additional Info'].str.contains('Windows', case=False, na=False))
            ]
            if not windows_vm_data.empty:
                total_windows_cost = windows_vm_data['Cost'].sum()
                hybrid_benefit['windows_vms'] = {
                    'current_monthly_cost': total_windows_cost,
                    'hybrid_benefit_savings': total_windows_cost * 0.40,  # Up to 40% savings
                    'recommendation': 'Apply Azure Hybrid Benefit for Windows Server licenses'
                }
            
            # SQL Server Hybrid Benefit
            sql_data = self.billing_data[self.billing_data['Service'].str.contains('SQL', case=False, na=False)]
            if not sql_data.empty:
                total_sql_cost = sql_data['Cost'].sum()
                hybrid_benefit['sql_server'] = {
                    'current_monthly_cost': total_sql_cost,
                    'hybrid_benefit_savings': total_sql_cost * 0.55,  # Up to 55% savings
                    'recommendation': 'Apply Azure Hybrid Benefit for SQL Server licenses'
                }
        
        except Exception as e:
            logger.error(f"Error analyzing Azure Hybrid Benefit: {str(e)}")
        
        return hybrid_benefit

    def analyze_storage_optimization(self) -> Dict:
        """Analyze Azure Storage optimization opportunities."""
        storage_analysis = {}
        
        try:
            if self.billing_data is None:
                return storage_analysis
            
            # Storage account analysis
            storage_data = self.billing_data[self.billing_data['Service'].str.contains('Storage', case=False, na=False)]
            if not storage_data.empty:
                total_storage_cost = storage_data['Cost'].sum()
                
                storage_analysis['storage_optimization'] = {
                    'current_monthly_cost': total_storage_cost,
                    'cool_tier_savings': total_storage_cost * 0.30,
                    'archive_tier_savings': total_storage_cost * 0.80,
                    'lifecycle_management_savings': total_storage_cost * 0.40,
                    'recommendations': [
                        'Move infrequently accessed data to Cool storage tier',
                        'Use Archive tier for long-term retention (>180 days)',
                        'Implement lifecycle management policies',
                        'Enable storage analytics to identify access patterns',
                        'Use Azure Storage reserved capacity for predictable workloads'
                    ]
                }
        
        except Exception as e:
            logger.error(f"Error analyzing Azure storage optimization: {str(e)}")
        
        return storage_analysis

    def get_comprehensive_azure_analysis(self, query: str) -> str:
        """Get comprehensive Azure billing analysis based on user query."""
        try:
            if self.billing_data is None:
                return "No Azure billing data loaded. Please load billing data first."
            
            # Generate billing summary
            billing_summary = f"""
            Azure Billing Summary:
            - Total Cost: ${self.billing_data['Cost'].sum():.2f}
            - Number of Services: {len(self.billing_data['Service'].unique()) if 'Service' in self.billing_data.columns else 'N/A'}
            - Top Services by Cost: {self.billing_data.groupby('Service')['Cost'].sum().sort_values(ascending=False).head(5).to_dict() if 'Service' in self.billing_data.columns else 'N/A'}
            - Top Resource Groups: {self.billing_data.groupby('ResourceGroup')['Cost'].sum().sort_values(ascending=False).head(3).to_dict() if 'ResourceGroup' in self.billing_data.columns else 'N/A'}
            
            User Query: {query}
            """
            
            # Use LLM for analysis
            chain = self.analysis_prompt | self.llm | StrOutputParser()
            analysis = chain.invoke({"billing_summary": billing_summary})
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error in comprehensive Azure analysis: {str(e)}")
            return f"Error performing Azure analysis: {str(e)}"
    
    def analyze_azure_costs_with_data(self, query: str, azure_data: pd.DataFrame) -> str:
        """Analyze Azure costs with actual billing data to answer specific questions"""
        try:
            # Analyze the Azure billing data to provide context
            total_cost = 0
            cost_columns = ['PreTaxCost', 'Cost', 'cost', 'TotalCost']
            for col in cost_columns:
                if col in azure_data.columns:
                    total_cost = azure_data[col].sum()
                    break
            
            # Get top services by cost
            top_services_text = "Service breakdown not available"
            service_columns = ['ServiceName', 'Service', 'MeterCategory', 'service_name']
            cost_col = None
            for col in cost_columns:
                if col in azure_data.columns:
                    cost_col = col
                    break
            
            if cost_col:
                for service_col in service_columns:
                    if service_col in azure_data.columns:
                        top_services = azure_data.groupby(service_col)[cost_col].sum().sort_values(ascending=False).head(5)
                        top_services_text = "\n".join([f"- {service}: ${cost:,.2f}" for service, cost in top_services.items()])
                        break
            
            # Get date range
            date_range = "Date range not available"
            date_columns = ['UsageDateTime', 'Date', 'usage_start_date', 'BillingPeriodStartDate']
            for col in date_columns:
                if col in azure_data.columns:
                    try:
                        azure_data[col] = pd.to_datetime(azure_data[col])
                        min_date = azure_data[col].min().strftime('%Y-%m-%d')
                        max_date = azure_data[col].max().strftime('%Y-%m-%d')
                        date_range = f"{min_date} to {max_date}"
                        break
                    except:
                        continue
            
            # Create Azure-specific analysis prompt
            azure_query_prompt = ChatPromptTemplate.from_messages([
                ("system", """You are an Azure billing analysis expert. Answer the user's question based on the provided Azure billing data.
                
                Focus on Azure-specific services, pricing models, and cost optimization opportunities:
                - Virtual Machines (Reserved Instances, Spot VMs, right-sizing)
                - Azure Storage (Hot, Cool, Archive tiers, lifecycle policies)
                - Azure SQL Database (Serverless, Reserved Capacity, Elastic Pools)
                - Azure Functions (Consumption vs Premium vs Dedicated plans)
                - Azure Kubernetes Service optimization
                - Azure Hybrid Benefit for cost savings
                - Azure Reservations and Savings Plans
                - Azure Cost Management tools and recommendations
                """),
                ("user", """USER QUESTION: {query}

AZURE BILLING DATA ANALYSIS:
- Total Azure Cost: ${total_cost:,.2f}
- Date Range: {date_range}
- Data Points: {num_records} billing records

TOP AZURE SERVICES BY COST:
{top_services}

INSTRUCTIONS:
1. Answer the specific question asked by the user
2. Use the actual Azure billing data provided above
3. Focus on Azure-specific services and optimization recommendations
4. Provide actionable insights for Azure cost optimization
5. Include specific Azure tools and features (Cost Management, Advisor, etc.)
6. If the data doesn't directly answer the question, explain what can be determined from the available Azure data

Response:""")
            ])
            
            chain = azure_query_prompt | self.llm | StrOutputParser()
            response = chain.invoke({
                "query": query,
                "total_cost": total_cost,
                "date_range": date_range,
                "num_records": len(azure_data),
                "top_services": top_services_text
            })
            
            return response
            
        except Exception as e:
            logger.error(f"Error analyzing Azure costs with data: {str(e)}")
            return f"I encountered an error analyzing your Azure billing data: {str(e)}. Please ensure your Azure billing data is properly formatted."